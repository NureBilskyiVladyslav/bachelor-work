import os
import sys
import json
import html
import random
import config
import sqlite3
import asyncio
import datetime
import traceback

from logger import log, LogMode

from aiogram import Bot as AiogramBot, Dispatcher, executor, types, exceptions as tg_exceptions
from aiogram.dispatcher import FSMContext
from aiogram.types.message import ContentTypes, MediaGroup
from aiogram.types.input_file import InputFile
from aiogram.dispatcher.filters import Text, BoundFilter
from aiogram.types.reply_keyboard import ReplyKeyboardMarkup, KeyboardButton
from aiogram.types.inline_keyboard import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.contrib.fsm_storage.memory import MemoryStorage

from pyrogram import types as pyro_types, enums
from pyrogram.client import Client
from pyrogram.errors import exceptions as pyro_exceptions

from pyrogram.dispatcher import Dispatcher as PyroDispather
from patch_dispatcher import PatchedDispatcher

PyroDispather.handler_worker = PatchedDispatcher.handler_worker


bot = AiogramBot(config.BOT_TOKEN, parse_mode="HTML", disable_web_page_preview=True)
dp = Dispatcher(bot, storage=MemoryStorage())
app = Client("pyro_bot", api_id=config.API_ID, api_hash=config.API_HASH, bot_token=config.BOT_TOKEN)


class PrivateChatFilter(BoundFilter):
    key = "is_private_chat"

    def __init__(self, is_private_chat):
        self.is_private_chat = is_private_chat

    async def check(self, message: types.Message):
        return message.chat.type == "private"

dp.filters_factory.bind(PrivateChatFilter)


def get_dt_now():
    return datetime.datetime.fromtimestamp(datetime.datetime.utcnow().timestamp() + 3600 * 3)


async def cur_executor(command: str, *args):
    base = sqlite3.connect("main_base.db")

    cur = base.cursor()
    
    try:
        cur.execute(command, args)
        base.commit()
        result = cur.fetchall()
    except Exception as e:
        log(f"Get error when execute SQL: query: '{command}', args: '{args}', error type: '{type(e).__name__}', error text: '{str(e)}'", LogMode.ERROR)
        return []
    finally:
        if base:
            cur.close()
            base.close()

    return result


async def start_db():
    base = sqlite3.connect("main_base.db")

    if base:
        log("Database successfully connected", LogMode.OK)
    else:
        log("Database not connected", LogMode.ERROR)
        return

    cur = base.cursor()

    cur.execute("CREATE TABLE IF NOT EXISTS users(user_id BIGINT PRIMARY KEY NOT NULL, username TEXT NOT NULL, first_name TEXT NOT NULL, last_name TEXT NOT NULL);")
    base.commit()
    cur.execute("CREATE TABLE IF NOT EXISTS channels(channel_id BIGINT PRIMARY KEY NOT NULL, channel_title TEXT NOT NULL, channel_note TEXT NOT NULL);")
    base.commit()
    cur.execute("CREATE TABLE IF NOT EXISTS channel_admins(user_id BIGINT NOT NULL, channel_id BIGINT NOT NULL, PRIMARY KEY(user_id, channel_id));")
    base.commit()
    cur.execute("CREATE TABLE IF NOT EXISTS channel_editors(user_id BIGINT NOT NULL, channel_id BIGINT NOT NULL, PRIMARY KEY(user_id, channel_id));")
    base.commit()
    cur.execute("CREATE TABLE IF NOT EXISTS signatures(channel_id BIGINT PRIMARY KEY NOT NULL, signature TEXT NOT NULL);")
    base.commit()
    cur.execute("CREATE TABLE IF NOT EXISTS scheduled_deletes(msg_id BIGINT NOT NULL, channel_id BIGINT NOT NULL, schedule_timestamp BIGINT NOT NULL, PRIMARY KEY(msg_id, channel_id));")
    base.commit()
    cur.execute("CREATE TABLE IF NOT EXISTS scheduled_posts(post_id BIGINT NOT NULL, channel_id BIGINT NOT NULL, post_type TEXT NOT NULL, reply_to_post_id BIGINT, schedule_timestamp BIGINT NOT NULL, disable_preview BOOL NOT NULL, reply_markup_text TEXT NOT NULL, notify BOOL NOT NULL, delete_on BIGINT NOT NULL, need_off_comments BOOL NOT NULL, text_caption TEXT NOT NULL, media_info TEXT NOT NULL, status TEXT NOT NULL, other_info TEXT NOT NULL, PRIMARY KEY(post_id, channel_id));")
    base.commit()
    cur.execute("CREATE TABLE IF NOT EXISTS posted_ids(post_id BIGINT PRIMARY KEY NOT NULL, posted_ids_data TEXT NOT NULL);")
    base.commit()

    if base:
        cur.close()
        base.close()


def make_markup_for_post(reply_markup_text: str):
    if reply_markup_text == "Пост без кнопок":
        return None
    
    rows = reply_markup_text.split("\n")
    kb_list = []
    for row in rows:
        buttons = row.split(" | ")
        buttons_row = []
        for button in buttons:
            parts = button.split(" - ")
            if len(parts) != 2:
                raise ValueError()
            buttons_row.append(InlineKeyboardButton(*parts))
        kb_list.append(buttons_row)

    reply_markup = InlineKeyboardMarkup(inline_keyboard=kb_list)

    return reply_markup


def gen_rand_text():
    alph = list("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz")
    random.shuffle(alph)
    return "".join(alph[:10])


COMMENTS_QUEUE = list()


@app.on_message()
async def comments_handler(cl: Client, msg: pyro_types.Message):
    if msg.forward_from_chat and msg.chat.type in [enums.chat_type.ChatType.SUPERGROUP, enums.chat_type.ChatType.GROUP]:
        COMMENTS_QUEUE.append([msg, datetime.datetime.utcnow().timestamp()])


OFF_COMMENTS_QUEUE = list()


async def off_comm_loop():
    await asyncio.sleep(5)

    global IS_STOP
    IS_STOP = False

    count = 0
    log("Starting off comm loop", LogMode.INFO)
    while not IS_STOP:
        count += 1
        try:
            global COMMENTS_QUEUE, OFF_COMMENTS_QUEUE
            for off_comm_item_l in OFF_COMMENTS_QUEUE[:]:
                off_comm_item, off_ts = off_comm_item_l
                # item equal to dict *posted_ids[channel_id] = [mess.message_id]*
                off_comm_item: dict
                for channel_id, ids in off_comm_item.items():
                    for comment_l in COMMENTS_QUEUE[:]:
                        comment, comm_ts = comment_l
                        # comment equal to pyro Message
                        """{
                            "_": "Message",
                            "id": 1451,
                            "sender_chat": {
                                "_": "Chat",
                                "id": -1001273927997,
                                "type": "ChatType.CHANNEL",
                                "is_verified": false,
                                "is_restricted": false,
                                "is_creator": false,
                                "is_admin": true,
                                "is_scam": false,
                                "is_fake": false,
                                "is_stories_hidden": false,
                                "is_stories_unavailable": true,
                                "title": "Апрва",
                                "has_protected_content": false
                            },
                            "date": "2024-11-22 02:47:27",
                            "chat": {
                                "_": "Chat",
                                "id": -1001779590693,
                                "type": "ChatType.SUPERGROUP",
                                "is_forum": false,
                                "is_verified": false,
                                "is_restricted": false,
                                "is_creator": false,
                                "is_admin": true,
                                "is_scam": false,
                                "is_fake": false,
                                "is_stories_hidden": false,
                                "is_stories_unavailable": true,
                                "title": "Азз",
                                "has_protected_content": false,
                                "permissions": {
                                    "_": "ChatPermissions",
                                    "can_send_messages": true,
                                    "can_send_media_messages": true,
                                    "can_send_other_messages": true,
                                    "can_send_polls": true,
                                    "can_add_web_page_previews": true,
                                    "can_change_info": false,
                                    "can_invite_users": true,
                                    "can_pin_messages": false,
                                    "can_manage_topics": true
                                }
                            },
                            "forward_from_chat": {
                                "_": "Chat",
                                "id": -1001273927997,
                                "type": "ChatType.CHANNEL",
                                "is_verified": false,
                                "is_restricted": false,
                                "is_creator": false,
                                "is_admin": true,
                                "is_scam": false,
                                "is_fake": false,
                                "is_stories_unavailable": true,
                                "title": "Апрва",
                                "has_protected_content": false
                            },
                            "forward_from_message_id": 364,
                            "forward_date": "2024-11-22 02:47:24",
                            "mentioned": false,
                            "scheduled": false,
                            "from_scheduled": false,
                            "show_above_text": false,
                            "edit_hidden": false,
                            "has_protected_content": false,
                            "text": "some post 2",
                            "views": 2,
                            "forwards": 0,
                            "outgoing": false
                        }"""
                        comment: pyro_types.Message
                        if comment.sender_chat and comment.sender_chat.id == int(channel_id) and comment.forward_from_message_id in ids:
                            try:
                                await bot.delete_message(comment.chat.id, comment.id)
                            except:
                                pass
                            
                            COMMENTS_QUEUE.remove(comment_l)
                        elif datetime.datetime.utcnow().timestamp() - comm_ts > 10 * 60:
                            COMMENTS_QUEUE.remove(comment_l)

                if datetime.datetime.utcnow().timestamp() - off_ts > 10 * 60:
                    OFF_COMMENTS_QUEUE.remove(off_comm_item_l)

        except Exception as e:
            await errors_handler("[ OFF COMM LOOP ]", e)

        if count % 360 == 0:
            log(f"Off comm loop iteration number {count}", LogMode.INFO)
        await asyncio.sleep(10)
    
    log("Off comm loop closed", LogMode.INFO)


async def post_loop():
    await asyncio.sleep(5)

    global IS_STOP

    count = 0
    log("Starting post loop", LogMode.INFO)
    while not IS_STOP:
        count += 1
        try:
            res = await cur_executor("SELECT post_id, channel_id, post_type, reply_to_post_id, schedule_timestamp, disable_preview, reply_markup_text, notify, delete_on, need_off_comments, text_caption, media_info, other_info FROM scheduled_posts WHERE schedule_timestamp <= ? AND status=?;", int(get_dt_now().timestamp()), "scheduled")
            if res:
                for row in res:
                    try:
                        post_id, channel_id, post_type, reply_to_post_id, schedule_timestamp, disable_preview, reply_markup_text, notify, delete_on, need_off_comments, text_caption, media_info, post_data = row
                        if schedule_timestamp <= int(get_dt_now().timestamp()):
                            posted_ids_data = dict()
                            if reply_to_post_id:
                                posted_ids_data = await cur_executor("SELECT posted_ids_data FROM posted_ids WHERE post_id=?;", reply_to_post_id)
                                posted_ids_data: dict = json.loads(posted_ids_data[0][0]) if posted_ids_data else dict()

                            posted_ids = dict()

                            post_data: dict = json.loads(post_data)
                            delete_on = delete_on or "never"
                            if delete_on == "24":
                                delete_on = int(get_dt_now().timestamp() + 24 * 3600)
                            elif delete_on == "48":
                                delete_on = int(get_dt_now().timestamp() + 47 * 3600 + 1800)
                            add_signature = post_data.get("add_signature", False)

                            need_off_comments = need_off_comments or False

                            if post_type == "text":
                                text = text_caption
                                reply_markup = make_markup_for_post(reply_markup_text)

                                temp_text = text
                                if add_signature:
                                    db_data = await cur_executor("SELECT signature FROM signatures WHERE channel_id=?;", - (1_000_000_000_000 + channel_id))
                                    if db_data:
                                        temp_text += "\n\n" + db_data[0][0]
                                try:
                                    while True:
                                        try:
                                            mess = await bot.send_message(channel_id, temp_text, disable_notification=(not notify), reply_to_message_id=posted_ids_data.get(str(channel_id), [None])[0], reply_markup=reply_markup, disable_web_page_preview=disable_preview)
                                            break
                                        except tg_exceptions.NetworkError:
                                            continue
                                except tg_exceptions.MessageIsTooLong:
                                    unescaped_text = html.unescape(temp_text)
                                    while True:
                                        if "<" in unescaped_text:
                                            try:
                                                unescaped_text = unescaped_text[ : unescaped_text.index("<")] + unescaped_text[unescaped_text.index(">")+1 : ]
                                            except ValueError:
                                                break
                                        else:
                                            break

                                    log(f"Reach text limit in message in post_loop. Info: {post_data}", LogMode.ERROR)
                                    try:
                                        while True:
                                            try:
                                                mess = await bot.send_message(channel_id, text, disable_notification=(not notify), reply_to_message_id=posted_ids_data.get(str(channel_id), [None])[0], reply_markup=reply_markup, disable_web_page_preview=disable_preview)
                                                break
                                            except tg_exceptions.NetworkError:
                                                continue
                                    except Exception as e:
                                        await errors_handler("[ POST LOOP ]", e)
                                        await cur_executor("UPDATE scheduled_posts SET status=? WHERE post_id=?;", "error", post_id)
                                        continue
                                
                                await cur_executor("UPDATE scheduled_posts SET status=? WHERE post_id=? AND channel_id=?;", "posted", post_id, channel_id)

                                posted_ids[channel_id] = [mess.message_id]

                                if delete_on != "never":
                                    await cur_executor("INSERT INTO scheduled_deletes VALUES (?, ?, ?);", mess.message_id, channel_id, delete_on)

                                await asyncio.sleep(1)

                                if need_off_comments:
                                    OFF_COMMENTS_QUEUE.append([posted_ids, datetime.datetime.utcnow().timestamp()])

                                old_posted_ids = await cur_executor("SELECT posted_ids_data FROM posted_ids WHERE post_id=?;", post_id)

                                if old_posted_ids:
                                    old_posted_ids = old_posted_ids[0][0]
                                    old_posted_ids = json.loads(old_posted_ids)
                                    for k, v in old_posted_ids.items():
                                        posted_ids[k] = posted_ids.get(k, []) + v
                                    
                                    await cur_executor("UPDATE posted_ids SET posted_ids_data=? WHERE post_id=?;", json.dumps(posted_ids, ensure_ascii=False), post_id)
                                else:
                                    await cur_executor("INSERT INTO posted_ids VALUES(?, ?);", post_id, json.dumps(posted_ids, ensure_ascii=False))

                                log(f"Successfully sent text post with id {post_id} to channel {channel_id}", LogMode.OK)
                            elif post_type == "solo":
                                info = json.loads(media_info)
                                caption = text_caption

                                reply_markup = make_markup_for_post(reply_markup_text)

                                temp_caption = caption
                                if add_signature:
                                    db_data = await cur_executor("SELECT signature FROM signatures WHERE channel_id=?;", - (1_000_000_000_000 + channel_id))
                                    if db_data:
                                        temp_caption += "\n\n" + db_data[0][0]
                                try:
                                    while True:
                                        try:
                                            if info[1] == "photo":
                                                mess = await bot.send_photo(channel_id, info[0], caption=temp_caption, disable_notification=(not notify), reply_to_message_id=posted_ids_data.get(str(channel_id), [None])[0], reply_markup=reply_markup)
                                            elif info[1] == "video":
                                                mess = await bot.send_video(channel_id, info[0], caption=temp_caption, disable_notification=(not notify), reply_to_message_id=posted_ids_data.get(str(channel_id), [None])[0], reply_markup=reply_markup)
                                            break
                                        except tg_exceptions.NetworkError:
                                            continue
                                except tg_exceptions.BadRequest as e:
                                    if str(e) != "Message caption is too long":
                                        raise e
                                    
                                    unescaped_text = html.unescape(temp_caption)
                                    while True:
                                        if "<" in unescaped_text:
                                            try:
                                                unescaped_text = unescaped_text[ : unescaped_text.index("<")] + unescaped_text[unescaped_text.index(">")+1 : ]
                                            except ValueError:
                                                break
                                        else:
                                            break

                                    log(f"Reach text limit in message in post_loop. Info: {post_data}", LogMode.ERROR)
                                    try:
                                        while True:
                                            try:
                                                if info[1] == "photo":
                                                    mess = await bot.send_photo(channel_id, info[0], caption=caption, disable_notification=(not notify), reply_to_message_id=posted_ids_data.get(str(channel_id), [None])[0], reply_markup=reply_markup)
                                                elif info[1] == "video":
                                                    mess = await bot.send_video(channel_id, info[0], caption=caption, disable_notification=(not notify), reply_to_message_id=posted_ids_data.get(str(channel_id), [None])[0], reply_markup=reply_markup)
                                                break
                                            except tg_exceptions.NetworkError:
                                                continue
                                    except Exception as e:
                                        await errors_handler("[ POST LOOP ]", e)
                                        await cur_executor("UPDATE scheduled_posts SET status=? WHERE post_id=?;", "error", post_id)
                                        continue
                            
                                await cur_executor("UPDATE scheduled_posts SET status=? WHERE post_id=? AND channel_id=?;", "posted", post_id, channel_id)

                                posted_ids[channel_id] = [mess.message_id]

                                if delete_on != "never":
                                    await cur_executor("INSERT INTO scheduled_deletes VALUES (?, ?, ?);", mess.message_id, channel_id, delete_on)

                                await asyncio.sleep(1)

                                if need_off_comments:
                                    OFF_COMMENTS_QUEUE.append([posted_ids, datetime.datetime.utcnow().timestamp()])

                                old_posted_ids = await cur_executor("SELECT posted_ids_data FROM posted_ids WHERE post_id=?;", post_id)

                                if old_posted_ids:
                                    old_posted_ids = old_posted_ids[0][0]
                                    old_posted_ids = json.loads(old_posted_ids)
                                    for k, v in old_posted_ids.items():
                                        posted_ids[k] = posted_ids.get(k, []) + v
                                    
                                    await cur_executor("UPDATE posted_ids SET posted_ids_data=? WHERE post_id=?;", json.dumps(posted_ids, ensure_ascii=False), post_id)
                                else:
                                    await cur_executor("INSERT INTO posted_ids VALUES(?, ?);", post_id, json.dumps(posted_ids, ensure_ascii=False))

                                log(f"Successfully sent solo post with id {post_id} to channel {channel_id}", LogMode.OK)
                            elif post_type == "album":
                                media_group_ids = json.loads(media_info)
                                caption = text_caption
                                
                                mgi = media_group_ids[:]
                                media = MediaGroup()
                                info = mgi.pop(0)
                                temp_caption = caption
                                if add_signature:
                                    db_data = await cur_executor("SELECT signature FROM signatures WHERE channel_id=?;", - (1_000_000_000_000 + channel_id))
                                    if db_data:
                                        temp_caption += "\n\n" + db_data[0][0]
                                try:
                                    if info[1] == "photo":
                                        media.attach_photo(info[0], caption=temp_caption)
                                    elif info[1] == "video":
                                        media.attach_video(info[0], caption=temp_caption)
                                    for i in mgi:
                                        if i[1] == "photo":
                                            media.attach_photo(i[0])
                                        elif i[1] == "video":
                                            media.attach_video(i[0])

                                    while True:
                                        try:
                                            msgs = await bot.send_media_group(channel_id, media, disable_notification=(not notify), reply_to_message_id=posted_ids_data.get(str(channel_id), [None])[0])
                                            break
                                        except tg_exceptions.NetworkError:
                                            continue
                                except tg_exceptions.BadRequest as e:
                                    if str(e) != "Message caption is too long":
                                        raise e
                                    
                                    unescaped_text = html.unescape(temp_caption)
                                    while True:
                                        if "<" in unescaped_text:
                                            try:
                                                unescaped_text = unescaped_text[ : unescaped_text.index("<")] + unescaped_text[unescaped_text.index(">")+1 : ]
                                            except ValueError:
                                                break
                                        else:
                                            break

                                    log(f"Reach text limit in message in post_loop. Info: {post_data}", LogMode.ERROR)
                                    try:
                                        media = MediaGroup()
                                        if info[1] == "photo":
                                            media.attach_photo(info[0], caption=caption)
                                        elif info[1] == "video":
                                            media.attach_video(info[0], caption=caption)
                                        for i in mgi:
                                            if i[1] == "photo":
                                                media.attach_photo(i[0])
                                            elif i[1] == "video":
                                                media.attach_video(i[0])

                                        while True:
                                            try:
                                                msgs = await bot.send_media_group(channel_id, media, disable_notification=(not notify), reply_to_message_id=posted_ids_data.get(str(channel_id), [None])[0])
                                                break
                                            except tg_exceptions.NetworkError:
                                                continue
                                    except Exception as e:
                                        await errors_handler("[ POST LOOP ]", e)
                                        await cur_executor("UPDATE scheduled_posts SET status=? WHERE post_id=?;", "error", post_id)
                                        continue
                                
                                await cur_executor("UPDATE scheduled_posts SET status=? WHERE post_id=? AND channel_id=?;", "posted", post_id, channel_id)

                                ids = []
                                for mess in msgs:
                                    ids.append(mess.message_id)
                                if ids:
                                    posted_ids[channel_id] = ids

                                for mess in msgs:
                                    if delete_on != "never":
                                        await cur_executor("INSERT INTO scheduled_deletes VALUES (?, ?, ?);", mess.message_id, channel_id, delete_on)

                                await asyncio.sleep(1)

                                if need_off_comments:
                                    OFF_COMMENTS_QUEUE.append([posted_ids, datetime.datetime.utcnow().timestamp()])

                                if old_posted_ids:
                                    old_posted_ids = old_posted_ids[0][0]
                                    old_posted_ids = json.loads(old_posted_ids)
                                    for k, v in old_posted_ids.items():
                                        posted_ids[k] = posted_ids.get(k, []) + v
                                    
                                    await cur_executor("UPDATE posted_ids SET posted_ids_data=? WHERE post_id=?;", json.dumps(posted_ids, ensure_ascii=False), post_id)
                                else:
                                    await cur_executor("INSERT INTO posted_ids VALUES(?, ?);", post_id, json.dumps(posted_ids, ensure_ascii=False))

                                log(f"Successfully sent album post with id {post_id} to channel {channel_id}", LogMode.OK)
                    except tg_exceptions.BadRequest as e:
                        if "Message to be replied not found" in str(e):
                            log(f"Can not send post with id {msg_id} to chat {channel_id} because BadRequest: Message to be replied not found", LogMode.ERROR)
                            await cur_executor("UPDATE scheduled_posts SET status=? WHERE post_id=? AND channel_id=?;", "error", post_id, channel_id)
                        else:
                            raise e
                    except tg_exceptions.Unauthorized:
                        # aiogram.utils.exceptions.Unauthorized: Forbidden: bot is not a member of the channel chat
                        log(f"Can not send post with id {msg_id} to chat {channel_id} because bot kicked", LogMode.ERROR)
                        await cur_executor("UPDATE scheduled_posts SET status=? WHERE post_id=? AND channel_id=?;", "error", post_id, channel_id)
            res = await cur_executor("SELECT msg_id, channel_id, schedule_timestamp FROM scheduled_deletes WHERE schedule_timestamp <= ?;", int(get_dt_now().timestamp()))
            if res:
                for row in res:
                    msg_id, channel_id, schedule_timestamp = row
                    if schedule_timestamp <= int(get_dt_now().timestamp()):
                        try:
                            await bot.delete_message(channel_id, msg_id)
                            log(f"Successfully delete post with id {msg_id} in chat {channel_id}", LogMode.OK)
                        except tg_exceptions.MessageToDeleteNotFound:
                            pass
                        except Exception as e:
                            log(f"Can not delete post with id {msg_id} in chat {channel_id}", LogMode.ERROR)
                            await errors_handler("[ POST LOOP ]", e)
                        
                        await cur_executor("DELETE FROM scheduled_deletes WHERE msg_id=? AND channel_id=?;", msg_id, channel_id)
        except Exception as e:
            await errors_handler("[ POST LOOP ]", e)

        if count % 360 == 0:
            log(f"Post loop iteration number {count}", LogMode.INFO)
        
        await asyncio.sleep(10)
    
    log("Post loop closed", LogMode.INFO)


async def startup(dp):
    log("BOT STARTED", LogMode.OK)

    await start_db()

    global IS_STOP
    IS_STOP = False
    
    global POST_LOOP_TASK
    POST_LOOP_TASK = asyncio.create_task(post_loop())

    global OFF_COMM_TASK
    OFF_COMM_TASK = asyncio.create_task(off_comm_loop())

    await app.start()


async def shutdown(dp):
    log("BOT STOPED", LogMode.OK)
    
    global IS_STOP
    IS_STOP = True
    
    global POST_LOOP_TASK
    POST_LOOP_TASK.cancel()
    
    global OFF_COMM_TASK
    OFF_COMM_TASK.cancel()

    await app.stop(block=True)


main_menu_start_kb = ReplyKeyboardMarkup(keyboard=[
    [
        KeyboardButton("Меню адмінів"),
        KeyboardButton("Меню редакторів"),
    ],
], resize_keyboard=True, one_time_keyboard=True, input_field_placeholder="Обери дію нижче")

main_menu_admin_kb = ReplyKeyboardMarkup(keyboard=[
    [
        KeyboardButton("Редактори"),
        KeyboardButton("Канали"),
    ],
    [
        KeyboardButton("Новий пост"),
        KeyboardButton("Редакт кнопок поста"),
    ],
    [
        KeyboardButton("Скопіювати пост"),
        KeyboardButton("Відкладені"),
    ],
    [
        KeyboardButton("Підписи"),
    ],
    [
        KeyboardButton(text="Головне меню"),
    ],
], resize_keyboard=True, one_time_keyboard=True, input_field_placeholder="Обери дію нижче")

main_menu_editor_kb = ReplyKeyboardMarkup(keyboard=[
    [
        KeyboardButton("Новий пост"),
        KeyboardButton("Редакт кнопок поста"),
    ],
    [
        KeyboardButton("Скопіювати пост"),
        KeyboardButton("Відкладені"),
    ],
    [
        KeyboardButton("Підписи"),
    ],
    [
        KeyboardButton(text="Головне меню"),
    ],
], resize_keyboard=True, one_time_keyboard=True, input_field_placeholder="Обери дію нижче")

to_main_menu_kb = ReplyKeyboardMarkup(keyboard=[
    [
        KeyboardButton(text="Головне меню"),
    ],
], resize_keyboard=True, one_time_keyboard=True)

cancel_kb = ReplyKeyboardMarkup(keyboard=[
    [
        KeyboardButton(text="Відмінити"),
    ],
], resize_keyboard=True)


@dp.message_handler(is_private_chat=True, commands=["start"])
@dp.message_handler(lambda m: m.text == "Головне меню", is_private_chat=True)
async def start_func(message: types.Message):
    log(f"Start pressed by user {message.chat.id}", LogMode.INFO)

    await message.answer("Привіт! Я бот для менеджменту контенту в Telegram-каналах. Скористуйся кнопками нижче для навігації", reply_markup=main_menu_start_kb)

    res = await cur_executor("SELECT * FROM users WHERE user_id=?;", message.chat.id)
    if not res:
        await cur_executor("INSERT INTO users VALUES (?, ?, ?, ?);", message.from_user.id, (message.from_user.username or ""), message.from_user.first_name, (message.from_user.last_name or ""))


class FSMEditors(StatesGroup):
    add_editor_id = State()
    remove_editor_id = State()
    channel_id = State()


@dp.message_handler(lambda m: m.text == "Відмінити", is_private_chat=True, state="*")
async def cancel_func(message: types.Message, state: FSMContext):
    log(f"Cancel by user {message.chat.id}", LogMode.INFO)

    curr_state = await state.get_state()
    if curr_state is None:
        await message.reply("Процес не було розпочато", reply_markup=to_main_menu_kb)
        return
    await state.finish()
    await message.reply("Процес перервано", reply_markup=to_main_menu_kb)


@dp.message_handler(lambda m: m.text == "Меню адмінів", is_private_chat=True)
async def my_channels_admin_func(message: types.Message):
    log(f"Get my_channels_admin command by user {message.chat.id}", LogMode.INFO)

    await message.answer("Меню для адмінів", reply_markup=main_menu_admin_kb)


@dp.message_handler(lambda m: m.text == "Меню редакторів", is_private_chat=True)
async def my_channels_editor_func(message: types.Message):
    log(f"Get my_channels_editor command by user {message.chat.id}", LogMode.INFO)

    res = await cur_executor("SELECT * FROM channel_editors WHERE user_id=?;", message.chat.id)
    if res:
        await message.answer("Меню для редакторів", reply_markup=main_menu_editor_kb)
    else:
        await message.answer("Тебе ще не призначали редактором в жодному каналі", reply_markup=main_menu_start_kb)


@dp.message_handler(lambda m: m.text == "Редактори", is_private_chat=True)
async def editors_func(message: types.Message):
    log(f"Get editors command by user {message.chat.id}", LogMode.INFO)

    data = await cur_executor("SELECT * FROM channel_admins WHERE user_id=?;", message.chat.id)

    if not data:
        await message.answer("Спочатку додай хоча б один канал")
        return

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Головне меню"),
        ],
        [
            KeyboardButton(text="Додати редактора"),
        ],
        [
            KeyboardButton(text="Видалити редактора"),
        ],
        [
            KeyboardButton(text="Список редакторів"),
        ],
    ], resize_keyboard=True, one_time_keyboard=True, input_field_placeholder="Обери дію нижче")

    await message.answer("Меню налаштування редакторів", reply_markup=kb)


@dp.message_handler(lambda m: m.text in ["Додати редактора", "Видалити редактора"], is_private_chat=True)
async def editor_options_func(message: types.Message):
    log(f"Get add/remove editor command by user {message.chat.id}", LogMode.INFO)

    await message.answer("Введи айді користувача", reply_markup=cancel_kb)
    if message.text == "Додати редактора":
        await FSMEditors.add_editor_id.set()
    elif message.text == "Видалити редактора":
        await FSMEditors.remove_editor_id.set()


@dp.message_handler(state=FSMEditors.add_editor_id, is_private_chat=True)
async def add_editor_func(message: types.Message, state: FSMContext):
    log(f"Get add editor id {message.text} by user {message.chat.id}", LogMode.INFO)

    try:
        user_id = int(message.text, base=10)
        if user_id < 1:
            raise ValueError()
    except:
        await message.answer("Неправильно вказано айді, спробуй знову. Приклад: 12345")
        return

    res = await cur_executor("SELECT * FROM users WHERE user_id=?", user_id)
    if not res:
        await message.answer("Користувача с таким айді немає в базі даних, спробуй знову")
        return
    
    async with state.proxy() as data:
        data["user_id"] = user_id
        data["option"] = "add"
    await FSMEditors.channel_id.set()

    await message.answer("Введи айді каналу", reply_markup=cancel_kb)


@dp.message_handler(state=FSMEditors.remove_editor_id, is_private_chat=True)
async def remove_editor_func(message: types.Message, state: FSMContext):
    log(f"Get remove editor id {message.text} by user {message.chat.id}", LogMode.INFO)

    try:
        user_id = int(message.text, base=10)
        if user_id < 1:
            raise ValueError()
    except:
        await message.answer("Неправильно вказано айді, спробуй знову. Приклад: 12345")
        return

    res = await cur_executor("SELECT * FROM users WHERE user_id=?", user_id)
    if not res:
        await message.answer("Користувача с таким айді немає в базі даних, спробуй знову")
        return
    
    async with state.proxy() as data:
        data["user_id"] = user_id
        data["option"] = "remove"
    await FSMEditors.channel_id.set()

    await message.answer("Введи айді каналу", reply_markup=cancel_kb)


@dp.message_handler(state=FSMEditors.channel_id, is_private_chat=True)
async def channel_id_editor_func(message: types.Message, state: FSMContext):
    log(f"Get channel_id editor {message.text} by user {message.chat.id}", LogMode.INFO)

    try:
        channel_id = int(message.text, base=10)
        if channel_id < 1:
            raise ValueError()
    except:
        await message.answer("Неправильно вказано айді, спробуй знову. Приклад: 12345")
        return
    
    async with state.proxy() as data:
        user_id = data["user_id"]
        option = data["option"]
    
    if option == "add":
        db_data = await cur_executor("SELECT * FROM channel_editors WHERE user_id=? AND channel_id=?", user_id, channel_id)

        if db_data:
            await message.answer("Користувач з таким айді уже редактор в такому каналі, операцію завершено", reply_markup=to_main_menu_kb)
            await state.finish()
            return
        
        await cur_executor("INSERT INTO channel_editors VALUES (?, ?);", user_id, channel_id)
        await message.answer("Користувача призначено редактором в цьому каналі", reply_markup=to_main_menu_kb)

        await state.finish()
    else:
        db_data = await cur_executor("SELECT * FROM channel_editors WHERE user_id=? AND channel_id=?", user_id, channel_id)

        if not db_data:
            await message.answer("Користувач з таким айді уже НЕ редактор в такому каналі, операцію завершено", reply_markup=to_main_menu_kb)
            await state.finish()
            return
        
        await cur_executor("DELETE FROM channel_editors WHERE user_id=? AND channel_id=?;", user_id, channel_id)
        await message.answer("Користувач перестав бути редактором в цьому каналі", reply_markup=to_main_menu_kb)

        await state.finish()


@dp.message_handler(lambda m: m.text == "Список редакторів", is_private_chat=True)
async def editors_list_func(message: types.Message):
    log(f"Get editors list command by user {message.chat.id}", LogMode.INFO)

    res = await cur_executor("SELECT channel_id FROM channel_admins WHERE user_id=?;", message.chat.id)
    if not res:
        await message.answer("Спочатку додай хоча б один канал")
        return

    for x in res:
        res_2 = await cur_executor("SELECT user_id FROM channel_editors WHERE channel_id=?;", x[0])

        channel = await bot.get_chat(-(1_000_000_000_000+int(x[0])))

        text = f"Канал {x[0]} ({channel.title}):\n\n"
        for x in res_2:
            uid = int(x[0])
            try:
                user_chat = await bot.get_chat(uid)
                info = "@" + user_chat.username if user_chat.username else user_chat.first_name
            except:
                info = "empty"
            text += f"{uid} - {info}\n"
        
        if not res_2:
            text += f"(ще немає жодного редактора)\n"

        await message.answer(text, reply_markup=to_main_menu_kb)


class FSMСhannels(StatesGroup):
    add_channel_id = State()
    remove_channel_id = State()


@dp.message_handler(lambda m: m.text == "Канали", is_private_chat=True)
async def channels_func(message: types.Message):
    log(f"Get channels command by user {message.chat.id}", LogMode.INFO)

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Головне меню"),
        ],
        [
            KeyboardButton(text="Додати канал"),
        ],
        [
            KeyboardButton(text="Видалити канал"),
        ],
        [
            KeyboardButton(text="Список каналів"),
        ],
    ], resize_keyboard=True, one_time_keyboard=True, input_field_placeholder="Обери дію нижче")

    await message.answer("Меню налаштування каналів", reply_markup=kb)


@dp.message_handler(lambda m: m.text in ["Додати канал", "Видалити канал"], is_private_chat=True)
async def channel_options_func(message: types.Message):
    log(f"Get add/remove channel command by user {message.chat.id}", LogMode.INFO)

    if message.text == "Додати канал":
        await message.answer("Введи айді канала та коротку примітку через пробіл. Приклад: 12345 Новини Харкова", reply_markup=cancel_kb)
        await FSMСhannels.add_channel_id.set()
    elif message.text == "Видалити канал":
        await message.answer("Введи айді канала. Приклад: 12345", reply_markup=cancel_kb)
        await FSMСhannels.remove_channel_id.set()


@dp.message_handler(state=FSMСhannels.add_channel_id, is_private_chat=True)
async def add_channel_func(message: types.Message, state: FSMContext):
    log(f"Get add channel id {message.text} by user {message.chat.id}", LogMode.INFO)

    channel_id, channel_note = message.text.split(" ", maxsplit=1)

    try:
        channel_id = int(channel_id, base=10)
        if channel_id < 1:
            raise ValueError()
    except:
        await message.answer("Неправильно вказано айді, спробуй знову. Приклад: 12345 Новини Харкова")
        return
    
    try:
        channel = await bot.get_chat( - (1_000_000_000_000 + channel_id))

        if channel.type != "channel":
            await message.answer("Це не канал, спробуй знову")
            return
    except tg_exceptions.ChatNotFound:
        await message.answer("Бот не має доступу до каналу з таким айді, спробуй знову")
        return
    
    iam = await bot.get_chat_member( - (1_000_000_000_000 + channel_id), (await bot.get_me()).id)

    if iam.status != "administrator":
        await message.answer("Бот має бути адміністратором у вказаному каналі, спробуй знову")
        return
    if not all((iam.can_post_messages, iam.can_edit_messages, iam.can_delete_messages)):
        await message.answer("Бот повинен мати право додавання, редагування та видалення постів у вказаному каналі, спробуй знову")
        return

    res = await cur_executor("SELECT * FROM channel_admins WHERE channel_id=?;", channel_id)
    if res:
        await message.answer("Канал уже було додано, операцію завершено", reply_markup=to_main_menu_kb)
        await state.finish()
        return

    await cur_executor("INSERT INTO channel_admins VALUES (?, ?);", message.chat.id, channel_id)
    await message.answer("Канал успішно додано", reply_markup=to_main_menu_kb)

    res = await cur_executor("SELECT * FROM channels WHERE channel_id=?;", channel_id)
    if not res:
        await cur_executor("INSERT INTO channels VALUES (?, ?, ?);", channel_id, channel.title, channel_note)
    
    await state.finish()


@dp.message_handler(state=FSMСhannels.remove_channel_id, is_private_chat=True)
async def remove_channel_func(message: types.Message, state: FSMContext):
    log(f"Get remove channel id {message.text} by user {message.chat.id}", LogMode.INFO)

    try:
        channel_id = int(message.text, base=10)
        if channel_id < 1:
            raise ValueError()
    except:
        await message.answer("Неправильно вказано айді, спробуй знову. Приклад: 12345")
        return

    res = await cur_executor("SELECT * FROM channel_admins WHERE channel_id=?;", channel_id)
    if not res:
        await message.answer("Канал уже відсутній, операцію завершено", reply_markup=to_main_menu_kb)
        await state.finish()
        return
    
    await cur_executor("DELETE FROM channel_admins WHERE user_id=? AND channel_id=?;", message.chat.id, channel_id)
    await message.answer("Канал успішно видалено", reply_markup=to_main_menu_kb)

    await state.finish()


@dp.message_handler(lambda m: m.text == "Список каналів", is_private_chat=True)
async def channels_list_func(message: types.Message):
    log(f"Get channels list command by user {message.chat.id}", LogMode.INFO)

    res = await cur_executor("SELECT channel_id FROM channel_admins WHERE user_id=?;", message.chat.id)
    if not res:
        await message.answer("Спочатку додай хоча б один канал")
        return

    text = "Список каналів:\n\n"
    for x in res:
        channel_id = int(x[0])
        try:
            channel_chat = await bot.get_chat( - (1_000_000_000_000 + channel_id))
            info = "@" + channel_chat.username if channel_chat.username else channel_chat.title
            if channel_chat.linked_chat_id:
                try:
                    mbr = await bot.get_chat_member(channel_chat.linked_chat_id, bot.id)
                    if mbr.status != "administrator":
                        info += " - 💬❌"
                    elif not mbr.can_delete_messages:
                        info += " - 💬❌"
                    else:
                        info += " - 💬✅"
                except:
                    info += " - 💬❌"
                try:
                    note_data = await cur_executor("SELECT channel_note FROM channels WHERE channel_id=?;", channel_id)
                    info += f" ({note_data[0][0]})"
                except:
                    pass
        except:
            info = "empty"
        text += f"{channel_id} - {info}\n"
    
    await message.answer(text, reply_markup=to_main_menu_kb)


@dp.message_handler(lambda m: m.text == "Новий пост", is_private_chat=True)
async def new_post_func(message: types.Message):
    log(f"New post pressed by user {message.chat.id}", LogMode.INFO)

    res = await cur_executor("SELECT channel_id FROM channel_admins WHERE user_id=?;", message.chat.id)
    if not res:
        res = await cur_executor("SELECT channel_id FROM channel_editors WHERE user_id=?;", message.chat.id)
    if not res:
        await message.answer("Спочатку додай хоча б один канал", reply_markup=to_main_menu_kb)
        return
    
    await message.answer((
            "Обери тип поста:\n"
            "\n"
            "Текстовий пост - тільки текст з кнопками (можливе прикріплення картинки знизу через посилання)\n"
            "Сольний пост - одне фото/відео з текстом і кнопками\n"
            "Альбомний пост - до 10 фото/відео с текстом, але без кнопок\n"
        ), reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [
                    KeyboardButton("Текстовий пост"),
                ],
                [
                    KeyboardButton("Сольний пост"),
                ],
                [
                    KeyboardButton("Альбомний пост"),
                ],
            ], resize_keyboard=True, one_time_keyboard=True, input_field_placeholder="Обери дію нижче"
        ))


class FSMTextPost(StatesGroup):
    text = State()
    long_with_pic = State()
    add_signature = State()
    reply_markup = State()
    channel_id = State()
    notify = State()
    delete_on = State()
    need_off_comments = State()
    reply_to = State()
    schedule = State()


@dp.message_handler(lambda m: m.text == "Текстовий пост", is_private_chat=True)
async def text_post_func(message: types.Message):
    log(f"Text post pressed by user {message.chat.id}", LogMode.INFO)

    await message.answer("Надішли текст для поста", reply_markup=cancel_kb)
    await FSMTextPost.text.set()


@dp.message_handler(state=FSMTextPost.text, content_types=ContentTypes.all(), is_private_chat=True)
async def textpost_text_func(message: types.Message, state: FSMContext):
    log(f"Get textpost text by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return

    async with state.proxy() as data:
        data["text"] = message.parse_entities()
    await FSMTextPost.next()

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Пост без картинки"),
        ],
        [
            KeyboardButton(text="Відмінити"),
        ],
    ], resize_keyboard=True)

    await message.answer((
            "Відправ боту посилання на картинку, яка прикріпиться нижче до поста\n"
            "\n"
            "Наприклад: http://example1.com/pic/abcde.jpeg\n"
        ), reply_markup=kb)


@dp.message_handler(state=FSMTextPost.long_with_pic, content_types=ContentTypes.all(), is_private_chat=True)
async def textpost_long_with_pic_func(message: types.Message, state: FSMContext):
    log(f"Get textpost long_with_pic by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return

    if message.text == "Пост без картинки":
        async with state.proxy() as data:
            data["disable_preview"] = True
    else:
        async with state.proxy() as data:
            data["text"] = f'<a href="{message.text}">⁠</a>' + data["text"]
            data["disable_preview"] = False
    await FSMTextPost.next()

    await message.answer((
        "Відправити пост з підписом?"
    ), reply_markup=ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton("Так"),
            ],
            [
                KeyboardButton("Ні"),
            ],
        ], resize_keyboard=True, input_field_placeholder="Обери дію нижче"
    ))


@dp.message_handler(state=FSMTextPost.add_signature, content_types=ContentTypes.all(), is_private_chat=True)
async def textpost_add_signature_func(message: types.Message, state: FSMContext):
    log(f"Get textpost add_signature by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return
    if message.text not in ["Так", "Ні"]:
        await message.answer("Відправ мені Так чи Ні")
        return

    if message.text == "Так":
        async with state.proxy() as data:
            data["add_signature"] = True
        await FSMTextPost.next()
    elif message.text == "Ні":
        async with state.proxy() as data:
            data["add_signature"] = False
        await FSMTextPost.next()

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Пост без кнопок"),
        ],
        [
            KeyboardButton(text="Відмінити"),
        ],
    ], resize_keyboard=True)

    await message.answer((
            "Відправ боту список URL-кнопок в наступному форматі:\n"
            "\n"
            "Кнопка 1 - http://example1.com\n"
            "Кнопка 2 - http://example2.com\n"
            "\n"
            "Використовуй роздільник \"|\", щоб додати до трьох кнопок в один ряд:\n"
            "\n"
            "Кнопка 1 - http://example1.com | Кнопка 2 - http://example2.com\n"
            "Кнопка 3 - http://example3.com | Кнопка 4 - http://example4.com\n"
        ), reply_markup=kb)


@dp.message_handler(state=FSMTextPost.reply_markup, content_types=ContentTypes.all(), is_private_chat=True)
async def textpost_reply_markup_func(message: types.Message, state: FSMContext):
    log(f"Get textpost reply_markup by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return
    
    if message.text == "Пост без кнопок":
        reply_markup = None
    else:
        try:
            rows = message.text.split("\n")
            kb_list = []
            for row in rows:
                buttons = row.split(" | ")
                if len(buttons) > 3:
                    await message.answer("Не можна більше 3 кнопок в ряд")
                    return
                buttons_row = []
                for button in buttons:
                    parts = button.split(" - ")
                    if len(parts) != 2:
                        raise ValueError()
                    buttons_row.append(InlineKeyboardButton(*parts))
                kb_list.append(buttons_row)
        except:
            await message.answer("Неправильний формат размітки, спробуй знову")
            return

        reply_markup = InlineKeyboardMarkup(inline_keyboard=kb_list)

    async with state.proxy() as data:
        data["reply_markup_text"] = message.text
    await FSMTextPost.next()
    
    await message.answer("Попередній перегляд поста (без підпису):")

    text = data["text"]
    await bot.send_message(message.chat.id, text, reply_markup=reply_markup, disable_web_page_preview=data["disable_preview"])

    res = await cur_executor("SELECT channel_id FROM channel_admins WHERE user_id=?;", message.chat.id)
    if not res:
        res = await cur_executor("SELECT channel_id FROM channel_editors WHERE user_id=?;", message.chat.id)
    
    channels_kb_list = []
    channels_kb_list.append([InlineKeyboardButton(text="Обрати всі", callback_data=f"channel_choose_all")])
    channels_kb_list.append([InlineKeyboardButton(text="Відмінити всі", callback_data=f"channel_cancel_all")])
    for row in res:
        channel_id = - (1_000_000_000_000 + int(row[0]))

        is_admin = False
        try:
            chat_member = await bot.get_chat_member(channel_id, message.chat.id)
        except tg_exceptions.BadRequest as e:
            if e.text != "User not found":
                raise e
        else:
            if chat_member.status in ["administrator", "owner", "creator"]:
                is_admin = True
        if not is_admin:
            continue

        channel = await bot.get_chat(channel_id)
        button = InlineKeyboardButton(text=channel.title, callback_data=f"channel_{channel_id}")
        channels_kb_list.append([button])

    if len(channels_kb_list) == 2:
        await message.answer("В жодному каналі у тебе немає прав адміністратора, процедуру перервано", reply_markup=to_main_menu_kb)
        await state.finish()
        return

    channels_kb_list.append([InlineKeyboardButton(text="Готово", callback_data=f"channel_accept")])

    await message.answer("Обери потрібні канали натиснувши на відповідні кнопки", reply_markup=InlineKeyboardMarkup(inline_keyboard=channels_kb_list))


@dp.callback_query_handler(Text(startswith="channel_"), state=FSMTextPost.channel_id)
async def textpost_channel_id_func(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()

    channel_id = callback.data.split("_", 1)[1]

    if channel_id == "choose_all":
        for row in callback.message.reply_markup.inline_keyboard[2:-1]:
            if row[0].text[0] != "✅":
                row[0].text = "✅" + row[0].text
        
        try:
            await callback.message.edit_reply_markup(callback.message.reply_markup)
        except tg_exceptions.MessageNotModified:
            pass
    elif channel_id == "cancel_all":
        for row in callback.message.reply_markup.inline_keyboard[2:-1]:
            if row[0].text[0] == "✅":
                row[0].text = row[0].text[1:]
        
        try:
            await callback.message.edit_reply_markup(callback.message.reply_markup)
        except tg_exceptions.MessageNotModified:
            pass
    elif channel_id == "accept":
        send_ids = []
        for row in callback.message.reply_markup.inline_keyboard[2:-1]:
            if row[0].text[0] == "✅":
                send_ids.append(int(row[0].callback_data.split("_")[1]))
        
        await callback.message.delete()
        
        async with state.proxy() as data:
            data["send_ids"] = send_ids
        await FSMTextPost.next()

        await callback.message.answer((
                "Відправити пост зі сповіщенням?"
            ), reply_markup=ReplyKeyboardMarkup(
                keyboard=[
                    [
                        KeyboardButton("Так"),
                    ],
                    [
                        KeyboardButton("Ні"),
                    ],
                ], resize_keyboard=True, input_field_placeholder="Обери дію нижче"
            ))
    else:
        for row in callback.message.reply_markup.inline_keyboard[1:-1]:
            if row[0].callback_data == callback.data:
                if row[0].text[0] == "✅":
                    row[0].text = row[0].text[1:]
                else:
                    row[0].text = "✅" + row[0].text
        await callback.message.edit_reply_markup(callback.message.reply_markup)


@dp.message_handler(state=FSMTextPost.notify, content_types=ContentTypes.all(), is_private_chat=True)
async def textpost_notify_func(message: types.Message, state: FSMContext):
    log(f"Get textpost notify by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return
    if message.text not in ["Так", "Ні"]:
        await message.answer("Відправ мені Так чи Ні")
        return

    if message.text == "Так":
        async with state.proxy() as data:
            data["notify"] = True
        await FSMTextPost.next()
    elif message.text == "Ні":
        async with state.proxy() as data:
            data["notify"] = False
        await FSMTextPost.next()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="24", callback_data="textpost_delete_on_24")
            ],
            [
                InlineKeyboardButton(text="48 (47.5)", callback_data="textpost_delete_on_48")
            ],
            [
                InlineKeyboardButton(text="Без автовидалення", callback_data="textpost_delete_on_never")
            ],
        ]
    )

    await message.answer(f"Обери, через скільки годин після публікації видалити пост", reply_markup=kb)


@dp.callback_query_handler(Text(startswith="textpost_delete_on_"), state=FSMTextPost.delete_on)
async def textpost_delete_on_func(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()

    delete_on = callback.data.split("textpost_delete_on_", 1)[1]

    await callback.message.delete()

    async with state.proxy() as data:
        data["delete_on"] = delete_on
    await FSMTextPost.next()

    await callback.message.answer((
        "Вимкнути коментарі до поста? (по можливості)"
    ), reply_markup=ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton("Так"),
            ],
            [
                KeyboardButton("Ні"),
            ],
        ], resize_keyboard=True, input_field_placeholder="Обери дію нижче"
    ))


@dp.message_handler(state=FSMTextPost.need_off_comments, content_types=ContentTypes.all(), is_private_chat=True)
async def textpost_need_off_comments_func(message: types.Message, state: FSMContext):
    log(f"Get textpost need_off_comments by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return
    if message.text not in ["Так", "Ні"]:
        await message.answer("Відправ мені Так чи Ні")
        return

    if message.text == "Так":
        async with state.proxy() as data:
            data["need_off_comments"] = True
        await FSMTextPost.next()
    elif message.text == "Ні":
        async with state.proxy() as data:
            data["need_off_comments"] = False
        await FSMTextPost.next()

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Без реплая"),
        ],
        [
            KeyboardButton(text="Відмінити"),
        ],
    ], resize_keyboard=True)

    await message.answer(f"Вкажи параметри для реплая: без нього (кнопка знизу) чи з ним - відправ посилання на один з постів в каналі виду https://t.me/c/1527486405/15087", reply_markup=kb)


@dp.message_handler(state=FSMTextPost.reply_to, content_types=ContentTypes.all(), is_private_chat=True)
async def textpost_reply_to_func(message: types.Message, state: FSMContext):
    log(f"Get textpost reply_to by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return

    if message.text == "Без реплая":
        async with state.proxy() as data:
            data["reply_to_post_id"] = None
        await FSMTextPost.next()
    else:
        # https://t.me/c/1527486405/15087
        if not message.text.startswith("https://t.me/"):
            await message.answer("Некоректний формат посилання, спробуй знову. Приклад коректного: https://t.me/c/1527486405/15087")
            return

        if message.text.startswith("https://t.me/c/"):
            ids = message.text[15:]
            try:
                ids = ids.split("/")
                if len(ids) != 2:
                    raise ValueError()
                for i in ids:
                    if int(i) < 0:
                        raise ValueError()
            except:
                await message.answer("Некоректний формат посилання, спробуй знову. Приклад коректного: https://t.me/c/1527486405/15087")
                return
        else:
            ids = message.text[13:]
            try:
                ids = ids.split("/")
                if len(ids) != 2:
                    raise ValueError()
                username, post_id = ids
                if int(post_id) < 0:
                    raise ValueError()
                try:
                    ch = await bot.get_chat("@"+username)
                    ids[0] = ch.id
                    if ids[0] < 0:
                        ids[0] = - (1_000_000_000_000 + ids[0])
                except Exception as e:
                    log(f"Can not resolve username for reply: '{type(e)}', '{e}'")
                    await message.answer(f"Не вдалося розпізнати юзернейм, спробуй знову")
                    return
            except:
                await message.answer("Некоректний формат посилання, спробуй знову. Приклад коректного: https://t.me/c/1527486405/15087")
                return

        channel_id, post_msg_id = ids
        channel_id = - (1_000_000_000_000 + int(channel_id))
        post_msg_id = int(post_msg_id)
        data = await cur_executor("SELECT * FROM posted_ids;")
        for row in data:
            post_id, posted_ids_data = row
            posted_ids_data: dict = json.loads(posted_ids_data)
            if post_msg_id in posted_ids_data.get(str(channel_id), []):
                async with state.proxy() as data:
                    data["reply_to_post_id"] = post_id
                await FSMTextPost.next()
                break
        else:
            await message.answer("Не знайдено записів з такими айдішками канала і поста в каналі, спробуй знову. Приклад коректного: https://t.me/c/1527486405/15087")
            return

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Відправити зараз"),
        ],
        [
            KeyboardButton(text="Відмінити"),
        ],
    ], resize_keyboard=True)

    await message.answer(f"Тепер відправ час по utc для відкладеної відправки у форматі 2025-06-23 02:11:58 (час на сервері: {get_dt_now()})", reply_markup=kb)


@dp.message_handler(state=FSMTextPost.schedule, content_types=ContentTypes.all(), is_private_chat=True)
async def textpost_schedule_func(message: types.Message, state: FSMContext):
    log(f"Get textpost schedule by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return

    if message.text == "Відправити зараз":
        async with state.proxy() as data:
            delete_on = data["delete_on"]
            if delete_on == "24":
                delete_on = int(get_dt_now().timestamp() + 24 * 3600)
            elif delete_on == "48":
                delete_on = int(get_dt_now().timestamp() + 47 * 3600 + 1800)
            
            posted_ids_data = dict()
            if data["reply_to_post_id"]:
                posted_ids_data: dict = json.loads((await cur_executor("SELECT posted_ids_data FROM posted_ids WHERE post_id=?;", data["reply_to_post_id"]))[0][0])

            posted_ids = dict()
            for channel_id in data["send_ids"]:
                text = data["text"]
                if data["add_signature"]:
                    db_data = await cur_executor("SELECT signature FROM signatures WHERE channel_id=?", - (1_000_000_000_000 + channel_id))
                    if db_data:
                        text += "\n\n" + db_data[0][0]
                reply_markup_text = data["reply_markup_text"]
                notify = data["notify"]
                
                while True:
                    try:
                        mess = await bot.send_message(channel_id, text, disable_notification=(not notify), reply_to_message_id=posted_ids_data.get(str(channel_id), [None])[0], reply_markup=make_markup_for_post(reply_markup_text), disable_web_page_preview=data["disable_preview"])
                        break
                    except tg_exceptions.NetworkError:
                        continue

                posted_ids[channel_id] = [mess.message_id]

                if delete_on != "never":
                    await cur_executor("INSERT INTO scheduled_deletes VALUES (?, ?, ?)", mess.message_id, channel_id, delete_on)
                
                await asyncio.sleep(1)
            
            if data["need_off_comments"]:
                OFF_COMMENTS_QUEUE.append([posted_ids, datetime.datetime.utcnow().timestamp()])

            while True:
                post_id = gen_rand_text()
                if not await cur_executor("SELECT post_id FROM scheduled_posts WHERE post_id=?;", post_id) and not await cur_executor("SELECT post_id FROM posted_ids WHERE post_id=?;", post_id):
                    break

            await cur_executor("INSERT INTO posted_ids VALUES(?, ?);", post_id, json.dumps(posted_ids, ensure_ascii=False))

        await message.answer("Текстовий пост успішно опубліковано в обрані канали", reply_markup=to_main_menu_kb)
        await state.finish()
    else:
        try:
            dt = datetime.datetime.fromisoformat(message.text)
        except:
            await message.answer("Неправильний формат")
            return

        if dt <= get_dt_now():
            await message.answer("Не вказуй минулий час")
            return
        
        if (datetime.datetime.fromisoformat(message.text) - get_dt_now()).days >= 365:
            await message.answer("Не вказуй час далі, ніж на рік в майбутнє")
            return
        
        async with state.proxy() as data:
            send_ids = data["send_ids"]
            text = data["text"]
            disable_preview = data["disable_preview"]
            add_signature = data["add_signature"]
            reply_markup_text = data["reply_markup_text"]
            notify = data["notify"]
            delete_on = data["delete_on"]
            need_off_comments = data["need_off_comments"]
            reply_to_post_id = data["reply_to_post_id"]
        
        await state.finish()

        while True:
            post_id = gen_rand_text()
            if not await cur_executor("SELECT post_id FROM scheduled_posts WHERE post_id=?;", post_id) and not await cur_executor("SELECT post_id FROM posted_ids WHERE post_id=?;", post_id):
                break
        
        post_data = {
            "send_ids": send_ids,
            "add_signature": add_signature,
        }


        for send_id in send_ids:
            await cur_executor("INSERT INTO scheduled_posts VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);",
                               post_id,
                               - (1_000_000_000_000 + int(send_id)),
                               "text",
                               reply_to_post_id,
                               int(datetime.datetime.fromisoformat(message.text).timestamp()),
                               disable_preview,
                               reply_markup_text,
                               notify,
                               delete_on,
                               need_off_comments,
                               text,
                               "",
                               "scheduled",
                               json.dumps(post_data, ensure_ascii=False, indent=4),
                            )

        await message.answer(f"Текстовий пост успішно додано до відкладених (айді: {post_id})", reply_markup=to_main_menu_kb)


class FSMSoloPost(StatesGroup):
    media = State()
    caption = State()
    add_signature = State()
    reply_markup = State()
    channel_id = State()
    notify = State()
    delete_on = State()
    need_off_comments = State()
    reply_to = State()
    schedule = State()


@dp.message_handler(lambda m: m.text == "Сольний пост", is_private_chat=True)
async def solo_post_func(message: types.Message):
    log(f"Solo post pressed by user {message.chat.id}", LogMode.INFO)

    await message.answer("Відправ одне фото або відео (не файлом)", reply_markup=cancel_kb)
    await FSMSoloPost.media.set()


@dp.message_handler(state=FSMSoloPost.media, content_types=ContentTypes.all(), is_private_chat=True)
async def solopost_media_func(message: types.Message, state: FSMContext):
    log(f"Get solopost media by user {message.chat.id}", LogMode.INFO)

    if message.photo:
        info = [message.photo[-1].file_id, "photo"]
    elif message.video:
        info = [message.video.file_id, "video"]
    else:
        await message.answer("Відправ мені одне фото або відео")
        return
    if message.media_group_id:
        await message.answer("Відправ мені ОДНЕ фото або відео")
        return

    async with state.proxy() as data:
        data["media"] = info
    await FSMSoloPost.next()
    await message.answer("Відправ текст поста (до 1024 символів; врахуй, що наявність підпису збільшує текст)", reply_markup=cancel_kb)


@dp.message_handler(state=FSMSoloPost.caption, content_types=ContentTypes.all(), is_private_chat=True)
async def solopost_caption_func(message: types.Message, state: FSMContext):
    log(f"Get solopost caption by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return
    if len(message.text) > 1024:
        await message.answer(f"Відправ текст довжиною ДО 1024 символів (врахуй, що наявність підпису збільшує текст). Зараз символів: {len(message.text)}")
        return

    async with state.proxy() as data:
        data["caption"] = message.parse_entities()
    await FSMSoloPost.next()

    await message.answer((
        "Відправити пост з підписом?"
    ), reply_markup=ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton("Так"),
            ],
            [
                KeyboardButton("Ні"),
            ],
        ], resize_keyboard=True, input_field_placeholder="Обери дію нижче"
    ))


@dp.message_handler(state=FSMSoloPost.add_signature, content_types=ContentTypes.all(), is_private_chat=True)
async def solopost_add_signature_func(message: types.Message, state: FSMContext):
    log(f"Get solopost add_signature by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return
    if message.text not in ["Так", "Ні"]:
        await message.answer("Відправ мені Так чи Ні")
        return

    if message.text == "Так":
        async with state.proxy() as data:
            data["add_signature"] = True
        await FSMSoloPost.next()
    elif message.text == "Ні":
        async with state.proxy() as data:
            data["add_signature"] = False
        await FSMSoloPost.next()

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Пост без кнопок"),
        ],
        [
            KeyboardButton(text="Відмінити"),
        ],
    ], resize_keyboard=True)

    await message.answer((
            "Відправ боту список URL-кнопок в наступному форматі:\n"
            "\n"
            "Кнопка 1 - http://example1.com\n"
            "Кнопка 2 - http://example2.com\n"
            "\n"
            "Використовуй роздільник \"|\", щоб додати до трьох кнопок в один ряд:\n"
            "\n"
            "Кнопка 1 - http://example1.com | Кнопка 2 - http://example2.com\n"
            "Кнопка 3 - http://example3.com | Кнопка 4 - http://example4.com\n"
        ), reply_markup=kb)


@dp.message_handler(state=FSMSoloPost.reply_markup, content_types=ContentTypes.all(), is_private_chat=True)
async def solopost_reply_markup_func(message: types.Message, state: FSMContext):
    log(f"Get solopost reply_markup by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return
    
    if message.text == "Пост без кнопок":
        reply_markup = None
    else:
        try:
            rows = message.text.split("\n")
            kb_list = []
            for row in rows:
                buttons = row.split(" | ")
                if len(buttons) > 3:
                    await message.answer("Не можна більше 3 кнопок в ряд")
                    return
                buttons_row = []
                for button in buttons:
                    parts = button.split(" - ")
                    if len(parts) != 2:
                        raise ValueError()
                    buttons_row.append(InlineKeyboardButton(*parts))
                kb_list.append(buttons_row)
        except:
            await message.answer("Неправильний формат размітки, спробуй знову")
            return

        reply_markup = InlineKeyboardMarkup(inline_keyboard=kb_list)

    async with state.proxy() as data:
        data["reply_markup_text"] = message.text
    await FSMSoloPost.next()
    
    await message.answer("Попередній перегляд поста (без підпису):")

    info = data["media"]
    caption = data["caption"]
    try:
        if info[1] == "photo":
            await bot.send_photo(message.chat.id, info[0], caption=caption, reply_markup=reply_markup)
        elif info[1] == "video":
            await bot.send_video(message.chat.id, info[0], caption=caption, reply_markup=reply_markup)
    except tg_exceptions.BadRequest:
        text = html.unescape(caption)
        while True:
            if "<" in text:
                try:
                    text = text[ : text.index("<")] + text[text.index(">")+1 : ]
                except ValueError:
                    break
            else:
                break

        await message.answer(f"Перевищено ліміт символів, операцію завершено. Ліміт: 1024. Довжина тексту в пості: {len(text)}", reply_markup=to_main_menu_kb)
        await state.finish()
        return
    
    res = await cur_executor("SELECT channel_id FROM channel_admins WHERE user_id=?;", message.chat.id)
    if not res:
        res = await cur_executor("SELECT channel_id FROM channel_editors WHERE user_id=?;", message.chat.id)
    
    channels_kb_list = []
    channels_kb_list.append([InlineKeyboardButton(text="Обрати всі", callback_data=f"channel_choose_all")])
    channels_kb_list.append([InlineKeyboardButton(text="Відмінити всі", callback_data=f"channel_cancel_all")])
    for row in res:
        channel_id = - (1_000_000_000_000 + int(row[0]))
        
        is_admin = False
        try:
            chat_member = await bot.get_chat_member(channel_id, message.chat.id)
        except tg_exceptions.BadRequest as e:
            if e.text != "User not found":
                raise e
        else:
            if chat_member.status in ["administrator", "owner", "creator"]:
                is_admin = True
        if not is_admin:
            continue

        channel = await bot.get_chat(channel_id)
        button = InlineKeyboardButton(text=channel.title, callback_data=f"channel_{channel_id}")
        channels_kb_list.append([button])

    if len(channels_kb_list) == 2:
        await message.answer("В жодному каналі у тебе немає прав адміністратора, процедуру перервано", reply_markup=to_main_menu_kb)
        await state.finish()
        return
    
    channels_kb_list.append([InlineKeyboardButton(text="Готово", callback_data=f"channel_accept")])

    await message.answer("Обери потрібні канали натиснувши на відповідні кнопки", reply_markup=InlineKeyboardMarkup(inline_keyboard=channels_kb_list))


@dp.callback_query_handler(Text(startswith="channel_"), state=FSMSoloPost.channel_id)
async def solopost_channel_id_func(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()

    channel_id = callback.data.split("_", 1)[1]

    if channel_id == "choose_all":
        for row in callback.message.reply_markup.inline_keyboard[2:-1]:
            if row[0].text[0] != "✅":
                row[0].text = "✅" + row[0].text
        
        try:
            await callback.message.edit_reply_markup(callback.message.reply_markup)
        except tg_exceptions.MessageNotModified:
            pass
    elif channel_id == "cancel_all":
        for row in callback.message.reply_markup.inline_keyboard[2:-1]:
            if row[0].text[0] == "✅":
                row[0].text = row[0].text[1:]
        
        try:
            await callback.message.edit_reply_markup(callback.message.reply_markup)
        except tg_exceptions.MessageNotModified:
            pass
    elif channel_id == "accept":
        send_ids = []
        for row in callback.message.reply_markup.inline_keyboard[1:-1]:
            if row[0].text[0] == "✅":
                send_ids.append(int(row[0].callback_data.split("_")[1]))
        
        await callback.message.edit_reply_markup()
        
        async with state.proxy() as data:
            data["send_ids"] = send_ids
        await FSMSoloPost.next()

        await callback.message.answer((
                "Відправити пост зі сповіщенням?"
            ), reply_markup=ReplyKeyboardMarkup(
                keyboard=[
                    [
                        KeyboardButton("Так"),
                    ],
                    [
                        KeyboardButton("Ні"),
                    ],
                ], resize_keyboard=True, input_field_placeholder="Обери дію нижче"
            ))
    else:
        for row in callback.message.reply_markup.inline_keyboard[1:-1]:
            if row[0].callback_data == callback.data:
                if row[0].text[0] == "✅":
                    row[0].text = row[0].text[1:]
                else:
                    row[0].text = "✅" + row[0].text
        await callback.message.edit_reply_markup(callback.message.reply_markup)


@dp.message_handler(state=FSMSoloPost.notify, content_types=ContentTypes.all(), is_private_chat=True)
async def solopost_notify_func(message: types.Message, state: FSMContext):
    log(f"Get solopost notify by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return
    if message.text not in ["Так", "Ні"]:
        await message.answer("Відправ мені Так чи Ні")
        return

    if message.text == "Так":
        async with state.proxy() as data:
            data["notify"] = True
        await FSMSoloPost.next()
    elif message.text == "Ні":
        async with state.proxy() as data:
            data["notify"] = False
        await FSMSoloPost.next()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="24", callback_data="solopost_delete_on_24")
            ],
            [
                InlineKeyboardButton(text="48 (47.5)", callback_data="solopost_delete_on_48")
            ],
            [
                InlineKeyboardButton(text="Без автовидалення", callback_data="solopost_delete_on_never")
            ],
        ]
    )

    await message.answer(f"Обери, через скільки годин після публікації видалити пост", reply_markup=kb)


@dp.callback_query_handler(Text(startswith="solopost_delete_on_"), state=FSMSoloPost.delete_on)
async def solopost_delete_on_func(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()

    delete_on = callback.data.split("solopost_delete_on_", 1)[1]

    await callback.message.delete()

    async with state.proxy() as data:
        data["delete_on"] = delete_on
    await FSMSoloPost.next()

    await callback.message.answer((
        "Вимкнути коментарі до поста? (по можливості)"
    ), reply_markup=ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton("Так"),
            ],
            [
                KeyboardButton("Ні"),
            ],
        ], resize_keyboard=True, input_field_placeholder="Обери дію нижче"
    ))


@dp.message_handler(state=FSMSoloPost.need_off_comments, content_types=ContentTypes.all(), is_private_chat=True)
async def solopost_need_off_comments_func(message: types.Message, state: FSMContext):
    log(f"Get solopost need_off_comments by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return
    if message.text not in ["Так", "Ні"]:
        await message.answer("Відправ мені Так чи Ні")
        return

    if message.text == "Так":
        async with state.proxy() as data:
            data["need_off_comments"] = True
        await FSMSoloPost.next()
    elif message.text == "Ні":
        async with state.proxy() as data:
            data["need_off_comments"] = False
        await FSMSoloPost.next()

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Без реплая"),
        ],
        [
            KeyboardButton(text="Відмінити"),
        ],
    ], resize_keyboard=True)

    await message.answer(f"Вкажи параметри для реплая: без нього (кнопка знизу) чи з ним - відправ посилання на один з постів в каналі виду https://t.me/c/1527486405/15087", reply_markup=kb)


@dp.message_handler(state=FSMSoloPost.reply_to, content_types=ContentTypes.all(), is_private_chat=True)
async def solopost_reply_to_func(message: types.Message, state: FSMContext):
    log(f"Get solopost reply_to by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return

    if message.text == "Без реплая":
        async with state.proxy() as data:
            data["reply_to_post_id"] = None
        await FSMSoloPost.next()
    else:
        # https://t.me/c/1527486405/15087
        if not message.text.startswith("https://t.me/"):
            await message.answer("Некоректний формат посилання, спробуй знову. Приклад коректного: https://t.me/c/1527486405/15087")
            return

        if message.text.startswith("https://t.me/c/"):
            ids = message.text[15:]
            try:
                ids = ids.split("/")
                if len(ids) != 2:
                    raise ValueError()
                for i in ids:
                    if int(i) < 0:
                        raise ValueError()
            except:
                await message.answer("Некоректний формат посилання, спробуй знову. Приклад коректного: https://t.me/c/1527486405/15087")
                return
        else:
            ids = message.text[13:]
            try:
                ids = ids.split("/")
                if len(ids) != 2:
                    raise ValueError()
                username, post_id = ids
                if int(post_id) < 0:
                    raise ValueError()
                try:
                    ch = await bot.get_chat("@"+username)
                    ids[0] = ch.id
                    if ids[0] < 0:
                        ids[0] = - (1_000_000_000_000 + ids[0])
                except Exception as e:
                    log(f"Can not resolve username for reply: '{type(e)}', '{e}'")
                    await message.answer(f"Не вдалося розпізнати юзернейм, спробуй знову")
                    return
            except:
                await message.answer("Некоректний формат посилання, спробуй знову. Приклад коректного: https://t.me/c/1527486405/15087")
                return

        channel_id, post_msg_id = ids
        channel_id = - (1_000_000_000_000 + int(channel_id))
        post_msg_id = int(post_msg_id)
        data = await cur_executor("SELECT * FROM posted_ids;")
        for row in data:
            post_id, posted_ids_data = row
            posted_ids_data: dict = json.loads(posted_ids_data)
            if post_msg_id in posted_ids_data.get(str(channel_id), []):
                async with state.proxy() as data:
                    data["reply_to_post_id"] = post_id
                await FSMSoloPost.next()
                break
        else:
            await message.answer("Не знайдено записів з такими айдішками канала і поста в каналі, спробуй знову. Приклад коректного: https://t.me/c/1527486405/15087")
            return

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Відправити зараз"),
        ],
        [
            KeyboardButton(text="Відмінити"),
        ],
    ], resize_keyboard=True)

    await message.answer(f"Тепер відправ час по utc для відкладеної відправки у форматі 2025-06-23 02:11:58 (час на сервері: {get_dt_now()})", reply_markup=kb)


@dp.message_handler(state=FSMSoloPost.schedule, content_types=ContentTypes.all(), is_private_chat=True)
async def solopost_schedule_func(message: types.Message, state: FSMContext):
    log(f"Get solopost schedule by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return

    if message.text == "Відправити зараз":
        async with state.proxy() as data:
            delete_on = data["delete_on"]
            if delete_on == "24":
                delete_on = int(get_dt_now().timestamp() + 24 * 3600)
            elif delete_on == "48":
                delete_on = int(get_dt_now().timestamp() + 47 * 3600 + 1800)
            
            posted_ids_data = dict()
            if data["reply_to_post_id"]:
                posted_ids_data: dict = json.loads((await cur_executor("SELECT posted_ids_data FROM posted_ids WHERE post_id=?;", data["reply_to_post_id"]))[0][0])

            posted_ids = dict()
            for channel_id in data["send_ids"]:
                info = data["media"]
                caption = data["caption"]
                if data["add_signature"]:
                    db_data = await cur_executor("SELECT signature FROM signatures WHERE channel_id=?", - (1_000_000_000_000 + channel_id))
                    if db_data:
                        caption += "\n\n" + db_data[0][0]
                reply_markup_text = data["reply_markup_text"]
                notify = data["notify"]
                
                while True:
                    try:
                        if info[1] == "photo":
                            mess = await bot.send_photo(channel_id, info[0], caption=caption, disable_notification=(not notify), reply_to_message_id=posted_ids_data.get(str(channel_id), [None])[0], reply_markup=make_markup_for_post(reply_markup_text))
                        elif info[1] == "video":
                            mess = await bot.send_video(channel_id, info[0], caption=caption, disable_notification=(not notify), reply_to_message_id=posted_ids_data.get(str(channel_id), [None])[0], reply_markup=make_markup_for_post(reply_markup_text))
                        break
                    except tg_exceptions.NetworkError:
                        continue

                posted_ids[channel_id] = [mess.message_id]

                if delete_on != "never":
                    await cur_executor("INSERT INTO scheduled_deletes VALUES (?, ?, ?)", mess.message_id, channel_id, delete_on)

                await asyncio.sleep(1)

            if data["need_off_comments"]:
                OFF_COMMENTS_QUEUE.append([posted_ids, datetime.datetime.utcnow().timestamp()])

            while True:
                post_id = gen_rand_text()
                if not await cur_executor("SELECT post_id FROM scheduled_posts WHERE post_id=?;", post_id) and not await cur_executor("SELECT post_id FROM posted_ids WHERE post_id=?;", post_id):
                    break

            await cur_executor("INSERT INTO posted_ids VALUES(?, ?);", post_id, json.dumps(posted_ids, ensure_ascii=False))

        await message.answer("Сольний пост успішно опубліковано в обрані канали", reply_markup=to_main_menu_kb)
        await state.finish()
    else:
        try:
            dt = datetime.datetime.fromisoformat(message.text)
        except:
            await message.answer("Неправильний формат")
            return

        if dt <= get_dt_now():
            await message.answer("Не вказуй минулий час")
            return
        
        if (datetime.datetime.fromisoformat(message.text) - get_dt_now()).days >= 365:
            await message.answer("Не вказуй час далі, ніж на рік в майбутнє")
            return
        
        async with state.proxy() as data:
            send_ids = data["send_ids"]
            media_info = data["media"]
            caption = data["caption"]
            add_signature = data["add_signature"]
            reply_markup_text = data["reply_markup_text"]
            notify = data["notify"]
            delete_on = data["delete_on"]
            need_off_comments = data["need_off_comments"]
            reply_to_post_id = data["reply_to_post_id"]
        
        await state.finish()

        while True:
            post_id = gen_rand_text()
            if not await cur_executor("SELECT post_id FROM scheduled_posts WHERE post_id=?;", post_id) and not await cur_executor("SELECT post_id FROM posted_ids WHERE post_id=?;", post_id):
                break
        
        post_data = {
            "send_ids": send_ids,
            "add_signature": add_signature,
        }

        for send_id in send_ids:
            await cur_executor("INSERT INTO scheduled_posts VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);",
                               post_id,
                               - (1_000_000_000_000 + int(send_id)),
                               "solo",
                               reply_to_post_id,
                               int(datetime.datetime.fromisoformat(message.text).timestamp()),
                               True,
                               reply_markup_text,
                               notify,
                               delete_on,
                               need_off_comments,
                               caption,
                               json.dumps(media_info, ensure_ascii=False, indent=4),
                               "scheduled",
                               json.dumps(post_data, ensure_ascii=False, indent=4),
                            )

        await message.answer(f"Сольний пост успішно додано до відкладених (айді: {post_id})", reply_markup=to_main_menu_kb)


class FSMAlbumPost(StatesGroup):
    media_group = State()
    caption = State()
    add_signature = State()
    channel_id = State()
    notify = State()
    delete_on = State()
    need_off_comments = State()
    reply_to = State()
    schedule = State()


@dp.message_handler(lambda m: m.text == "Альбомний пост", is_private_chat=True)
async def album_post_func(message: types.Message):
    log(f"Album post pressed by user {message.chat.id}", LogMode.INFO)

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Готово"),
        ],
        [
            KeyboardButton(text="Відмінити"),
        ],
    ], resize_keyboard=True)

    await message.answer("По черзі надсилай фото або відео (не файлами), а в кінці натисни кнопку Готово", reply_markup=kb)
    await FSMAlbumPost.media_group.set()


@dp.message_handler(state=FSMAlbumPost.media_group, content_types=ContentTypes.all(), is_private_chat=True)
async def albumpost_media_group_func(message: types.Message, state: FSMContext):
    log(f"Get albumpost media group by user {message.chat.id}", LogMode.INFO)

    if message.text == "Готово":
        await FSMAlbumPost.next()
        await message.answer("Альбом зібрано. Тепер надішли текст поста (до 1024 символів; врахуй, що наявність підпису збільшує текст)", reply_markup=cancel_kb)
        return

    if message.photo:
        info = [message.photo[-1].file_id, "photo"]
    elif message.video:
        info = [message.video.file_id, "video"]
    else:
        await message.answer("Відправ мені фото або відео")
        return

    async with state.proxy() as data:
        if not data.get("media_group"):
            data["media_group"] = []
        data["media_group"].append(info)
        if len(data["media_group"]) == 10:
            await FSMAlbumPost.next()
            await message.answer("Альбом зібрано. Тепер надішли текст поста (до 1024 символів; врахуй, що наявність підпису збільшує текст)", reply_markup=cancel_kb)


@dp.message_handler(state=FSMAlbumPost.caption, content_types=ContentTypes.all(), is_private_chat=True)
async def albumpost_caption_func(message: types.Message, state: FSMContext):
    log(f"Get albumpost caption by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return
    if len(message.text) > 1024:
        await message.answer(f"Відправ текст довжиною ДО 1024 символів (врахуй, що наявність підпису збільшує текст). Зараз символів: {len(message.text)}")
        return

    async with state.proxy() as data:
        data["caption"] = message.parse_entities()
    await FSMAlbumPost.next()

    await message.answer((
        "Відправити пост з підписом?"
    ), reply_markup=ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton("Так"),
            ],
            [
                KeyboardButton("Ні"),
            ],
        ], resize_keyboard=True, input_field_placeholder="Обери дію нижче"
    ))


@dp.message_handler(state=FSMAlbumPost.add_signature, content_types=ContentTypes.all(), is_private_chat=True)
async def albumpost_add_signature_func(message: types.Message, state: FSMContext):
    log(f"Get albumpost add_signature by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return
    if message.text not in ["Так", "Ні"]:
        await message.answer("Відправ мені Так чи Ні")
        return

    if message.text == "Так":
        async with state.proxy() as data:
            data["add_signature"] = True
        await FSMAlbumPost.next()
    elif message.text == "Ні":
        async with state.proxy() as data:
            data["add_signature"] = False
        await FSMAlbumPost.next()

    await message.answer("Попередній перегляд поста (без підпису):")

    media_group_ids: list = data["media_group"][:]
    caption = data["caption"]
    media = MediaGroup()
    info = media_group_ids.pop(0)
    try:
        if info[1] == "photo":
            media.attach_photo(info[0], caption=caption)
        elif info[1] == "video":
            media.attach_video(info[0], caption=caption)
        for info in media_group_ids:
            if info[1] == "photo":
                media.attach_photo(info[0])
            elif info[1] == "video":
                media.attach_video(info[0])

        await bot.send_media_group(message.chat.id, media)
    except tg_exceptions.BadRequest:
        text = html.unescape(caption)
        while True:
            if "<" in text:
                try:
                    text = text[ : text.index("<")] + text[text.index(">")+1 : ]
                except ValueError:
                    break
            else:
                break

        await message.answer(f"Перевищено ліміт символів, операцію завершено. Ліміт: 1024. Довжина тексту в пості: {len(text)}", reply_markup=to_main_menu_kb)
        await state.finish()
        return
    
    res = await cur_executor("SELECT channel_id FROM channel_admins WHERE user_id=?;", message.chat.id)
    if not res:
        res = await cur_executor("SELECT channel_id FROM channel_editors WHERE user_id=?;", message.chat.id)
    
    channels_kb_list = []
    channels_kb_list.append([InlineKeyboardButton(text="Обрати всі", callback_data=f"channel_choose_all")])
    channels_kb_list.append([InlineKeyboardButton(text="Відмінити всі", callback_data=f"channel_cancel_all")])
    for row in res:
        channel_id = - (1_000_000_000_000 + int(row[0]))
        
        is_admin = False
        try:
            chat_member = await bot.get_chat_member(channel_id, message.chat.id)
        except tg_exceptions.BadRequest as e:
            if e.text != "User not found":
                raise e
        else:
            if chat_member.status in ["administrator", "owner", "creator"]:
                is_admin = True
        if not is_admin:
            continue

        channel = await bot.get_chat(channel_id)
        button = InlineKeyboardButton(text=channel.title, callback_data=f"channel_{channel_id}")
        channels_kb_list.append([button])

    if len(channels_kb_list) == 2:
        await message.answer("В жодному каналі у тебе немає прав адміністратора, процедуру перервано", reply_markup=to_main_menu_kb)
        await state.finish()
        return
    
    channels_kb_list.append([InlineKeyboardButton(text="Готово", callback_data=f"channel_accept")])

    await message.answer("Обери потрібні канали натиснувши на відповідні кнопки", reply_markup=InlineKeyboardMarkup(inline_keyboard=channels_kb_list))


@dp.callback_query_handler(Text(startswith="channel_"), state=FSMAlbumPost.channel_id)
async def albumpost_channel_id_func(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()

    channel_id = callback.data.split("_", 1)[1]

    if channel_id == "choose_all":
        for row in callback.message.reply_markup.inline_keyboard[2:-1]:
            if row[0].text[0] != "✅":
                row[0].text = "✅" + row[0].text
        
        try:
            await callback.message.edit_reply_markup(callback.message.reply_markup)
        except tg_exceptions.MessageNotModified:
            pass
    elif channel_id == "cancel_all":
        for row in callback.message.reply_markup.inline_keyboard[2:-1]:
            if row[0].text[0] == "✅":
                row[0].text = row[0].text[1:]
        
        try:
            await callback.message.edit_reply_markup(callback.message.reply_markup)
        except tg_exceptions.MessageNotModified:
            pass
    elif channel_id == "accept":
        send_ids = []
        for row in callback.message.reply_markup.inline_keyboard[1:-1]:
            if row[0].text[0] == "✅":
                send_ids.append(int(row[0].callback_data.split("_")[1]))
        
        await callback.message.edit_reply_markup()
        
        async with state.proxy() as data:
            data["send_ids"] = send_ids
        await FSMAlbumPost.next()

        await callback.message.answer((
                "Відправити пост зі сповіщенням?"
            ), reply_markup=ReplyKeyboardMarkup(
                keyboard=[
                    [
                        KeyboardButton("Так"),
                    ],
                    [
                        KeyboardButton("Ні"),
                    ],
                ], resize_keyboard=True, input_field_placeholder="Обери дію нижче"
            ))
    else:
        for row in callback.message.reply_markup.inline_keyboard[1:-1]:
            if row[0].callback_data == callback.data:
                if row[0].text[0] == "✅":
                    row[0].text = row[0].text[1:]
                else:
                    row[0].text = "✅" + row[0].text
        await callback.message.edit_reply_markup(callback.message.reply_markup)


@dp.message_handler(state=FSMAlbumPost.notify, content_types=ContentTypes.all(), is_private_chat=True)
async def albumpost_notify_func(message: types.Message, state: FSMContext):
    log(f"Get albumpost notify by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return
    if message.text not in ["Так", "Ні"]:
        await message.answer("Відправ мені Так чи Ні")
        return

    if message.text == "Так":
        async with state.proxy() as data:
            data["notify"] = True
        await FSMAlbumPost.next()
    elif message.text == "Ні":
        async with state.proxy() as data:
            data["notify"] = False
        await FSMAlbumPost.next()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="24", callback_data="albumpost_delete_on_24")
            ],
            [
                InlineKeyboardButton(text="48 (47.5)", callback_data="albumpost_delete_on_48")
            ],
            [
                InlineKeyboardButton(text="Без автовидалення", callback_data="albumpost_delete_on_never")
            ],
        ]
    )

    await message.answer(f"Обери, через скільки годин після публікації видалити пост", reply_markup=kb)


@dp.callback_query_handler(Text(startswith="albumpost_delete_on_"), state=FSMAlbumPost.delete_on)
async def albumpost_delete_on_func(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()

    delete_on = callback.data.split("albumpost_delete_on_", 1)[1]

    await callback.message.delete()

    async with state.proxy() as data:
        data["delete_on"] = delete_on
    await FSMAlbumPost.next()

    await callback.message.answer((
        "Вимкнути коментарі до поста? (по можливості)"
    ), reply_markup=ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton("Так"),
            ],
            [
                KeyboardButton("Ні"),
            ],
        ], resize_keyboard=True, input_field_placeholder="Обери дію нижче"
    ))


@dp.message_handler(state=FSMAlbumPost.need_off_comments, content_types=ContentTypes.all(), is_private_chat=True)
async def albumpost_need_off_comments_func(message: types.Message, state: FSMContext):
    log(f"Get albumpost need_off_comments by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return
    if message.text not in ["Так", "Ні"]:
        await message.answer("Відправ мені Так чи Ні")
        return

    if message.text == "Так":
        async with state.proxy() as data:
            data["need_off_comments"] = True
        await FSMAlbumPost.next()
    elif message.text == "Ні":
        async with state.proxy() as data:
            data["need_off_comments"] = False
        await FSMAlbumPost.next()

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Без реплая"),
        ],
        [
            KeyboardButton(text="Відмінити"),
        ],
    ], resize_keyboard=True)

    await message.answer(f"Вкажи параметри для реплая: без нього (кнопка знизу) чи з ним - відправ посилання на один з постів в каналі виду https://t.me/c/1527486405/15087", reply_markup=kb)


@dp.message_handler(state=FSMAlbumPost.reply_to, content_types=ContentTypes.all(), is_private_chat=True)
async def albumpost_reply_to_func(message: types.Message, state: FSMContext):
    log(f"Get albumpost reply_to by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return

    if message.text == "Без реплая":
        async with state.proxy() as data:
            data["reply_to_post_id"] = None
        await FSMAlbumPost.next()
    else:
        # https://t.me/c/1527486405/15087
        if not message.text.startswith("https://t.me/"):
            await message.answer("Некоректний формат посилання, спробуй знову. Приклад коректного: https://t.me/c/1527486405/15087")
            return

        if message.text.startswith("https://t.me/c/"):
            ids = message.text[15:]
            try:
                ids = ids.split("/")
                if len(ids) != 2:
                    raise ValueError()
                for i in ids:
                    if int(i) < 0:
                        raise ValueError()
            except:
                await message.answer("Некоректний формат посилання, спробуй знову. Приклад коректного: https://t.me/c/1527486405/15087")
                return
        else:
            ids = message.text[13:]
            try:
                ids = ids.split("/")
                if len(ids) != 2:
                    raise ValueError()
                username, post_id = ids
                if int(post_id) < 0:
                    raise ValueError()
                try:
                    ch = await bot.get_chat("@"+username)
                    ids[0] = ch.id
                    if ids[0] < 0:
                        ids[0] = - (1_000_000_000_000 + ids[0])
                except Exception as e:
                    log(f"Can not resolve username for reply: '{type(e)}', '{e}'")
                    await message.answer(f"Не вдалося розпізнати юзернейм, спробуй знову")
                    return
            except:
                await message.answer("Некоректний формат посилання, спробуй знову. Приклад коректного: https://t.me/c/1527486405/15087")
                return

        channel_id, post_msg_id = ids
        channel_id = - (1_000_000_000_000 + int(channel_id))
        post_msg_id = int(post_msg_id)
        data = await cur_executor("SELECT * FROM posted_ids;")
        for row in data:
            post_id, posted_ids_data = row
            posted_ids_data: dict = json.loads(posted_ids_data)
            if post_msg_id in posted_ids_data.get(str(channel_id), []):
                async with state.proxy() as data:
                    data["reply_to_post_id"] = post_id
                await FSMAlbumPost.next()
                break
        else:
            await message.answer("Не знайдено записів з такими айдішками канала і поста в каналі, спробуй знову. Приклад коректного: https://t.me/c/1527486405/15087")
            return

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Відправити зараз"),
        ],
        [
            KeyboardButton(text="Відмінити"),
        ],
    ], resize_keyboard=True)

    await message.answer(f"Тепер відправ час по utc для відкладеної відправки у форматі 2025-06-23 02:11:58 (час на сервері: {get_dt_now()})", reply_markup=kb)


@dp.message_handler(state=FSMAlbumPost.schedule, content_types=ContentTypes.all(), is_private_chat=True)
async def albumpost_schedule_func(message: types.Message, state: FSMContext):
    log(f"Get albumpost schedule by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return

    if message.text == "Відправити зараз":
        async with state.proxy() as data:
            delete_on = data["delete_on"]
            if delete_on == "24":
                delete_on = int(get_dt_now().timestamp() + 24 * 3600)
            elif delete_on == "48":
                delete_on = int(get_dt_now().timestamp() + 47 * 3600 + 1800)
            
            posted_ids_data = dict()
            if data["reply_to_post_id"]:
                posted_ids_data: dict = json.loads((await cur_executor("SELECT posted_ids_data FROM posted_ids WHERE post_id=?;", data["reply_to_post_id"]))[0][0])

            posted_ids = dict()
            for channel_id in data["send_ids"]:
                media_group_ids: list = data["media_group"][:]
                caption = data["caption"]
                if data["add_signature"]:
                    db_data = await cur_executor("SELECT signature FROM signatures WHERE channel_id=?", - (1_000_000_000_000 + channel_id))
                    if db_data:
                        caption += "\n\n" + db_data[0][0]
                notify = data["notify"]
                media = MediaGroup()
                info = media_group_ids.pop(0)
                if info[1] == "photo":
                    media.attach_photo(info[0], caption=caption)
                elif info[1] == "video":
                    media.attach_video(info[0], caption=caption)
                for info in media_group_ids:
                    if info[1] == "photo":
                        media.attach_photo(info[0])
                    elif info[1] == "video":
                        media.attach_video(info[0])

                while True:
                    try:
                        msgs = await bot.send_media_group(channel_id, media, disable_notification=(not notify), reply_to_message_id=posted_ids_data.get(str(channel_id), [None])[0])
                        break
                    except tg_exceptions.NetworkError:
                        continue

                ids = []
                for mess in msgs:
                    ids.append(mess.message_id)
                if ids:
                    posted_ids[channel_id] = ids

                for mess in msgs:
                    if delete_on != "never":
                        await cur_executor("INSERT INTO scheduled_deletes VALUES (?, ?, ?);", mess.message_id, channel_id, delete_on)

                await asyncio.sleep(1)

            if data["need_off_comments"]:
                OFF_COMMENTS_QUEUE.append([posted_ids, datetime.datetime.utcnow().timestamp()])

            while True:
                post_id = gen_rand_text()
                if not await cur_executor("SELECT post_id FROM scheduled_posts WHERE post_id=?;", post_id) and not await cur_executor("SELECT post_id FROM posted_ids WHERE post_id=?;", post_id):
                    break

            await cur_executor("INSERT INTO posted_ids VALUES(?, ?);", post_id, json.dumps(posted_ids, ensure_ascii=False))

        await message.answer("Альбомний пост успішно опубліковано в обрані канали", reply_markup=to_main_menu_kb)
        await state.finish()
    else:
        try:
            dt = datetime.datetime.fromisoformat(message.text)
        except:
            await message.answer("Неправильний формат")
            return

        if dt <= get_dt_now():
            await message.answer("Не вказуй минулий час")
            return
        
        if (datetime.datetime.fromisoformat(message.text) - get_dt_now()).days >= 365:
            await message.answer("Не вказуй час далі, ніж на рік в майбутнє")
            return
        
        async with state.proxy() as data:
            send_ids = data["send_ids"]
            media_group_ids = data["media_group"]
            caption = data["caption"]
            add_signature = data["add_signature"]
            notify = data["notify"]
            delete_on = data["delete_on"]
            need_off_comments = data["need_off_comments"]
            reply_to_post_id = data["reply_to_post_id"]
        
        await state.finish()

        while True:
            post_id = gen_rand_text()
            if not await cur_executor("SELECT post_id FROM scheduled_posts WHERE post_id=?;", post_id) and not await cur_executor("SELECT post_id FROM posted_ids WHERE post_id=?;", post_id):
                break
        
        post_data = {
            "send_ids": send_ids,
            "add_signature": add_signature,
        }

        for send_id in send_ids:
            await cur_executor("INSERT INTO scheduled_posts VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);",
                               post_id,
                               - (1_000_000_000_000 + int(send_id)),
                               "album",
                               reply_to_post_id,
                               int(datetime.datetime.fromisoformat(message.text).timestamp()),
                               True,
                               "",
                               notify,
                               delete_on,
                               need_off_comments,
                               caption,
                               json.dumps(media_group_ids, ensure_ascii=False, indent=4),
                               "scheduled",
                               json.dumps(post_data, ensure_ascii=False, indent=4),
                            )

        await message.answer(f"Альбомний пост успішно додано до відкладених (айді: {post_id})", reply_markup=to_main_menu_kb)
        
    await state.finish()


class FSMEditPost(StatesGroup):
    get_post = State()
    reply_markup = State()


@dp.message_handler(lambda m: m.text == "Редакт кнопок поста", is_private_chat=True)
async def edit_post_func(message: types.Message):
    log(f"Edit_post pressed by user {message.chat.id}", LogMode.INFO)

    await message.answer("Перешли сольний пост з кнопками в цей чат", reply_markup=cancel_kb)
    await FSMEditPost.get_post.set()


@dp.message_handler(state=FSMEditPost.get_post, content_types=ContentTypes.all(), is_private_chat=True)
async def editpost_get_post_func(message: types.Message, state: FSMContext):
    log(f"Get editpost get post by user {message.chat.id}", LogMode.INFO)

    if not message.forward_from_chat or message.forward_from_chat.type != "channel":
        await message.answer("Перешли мені пост з канала")
        return
    if not message.reply_markup:
        await message.answer("Перешли мені пост з кнопками")
        return

    async with state.proxy() as data:
        data["msg"] = message
    await FSMEditPost.next()

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Пост без кнопок"),
        ],
        [
            KeyboardButton(text="Відмінити"),
        ],
    ], resize_keyboard=True)

    await message.answer((
            "Відправ боту список URL-кнопок в наступному форматі:\n"
            "\n"
            "Кнопка 1 - http://example1.com\n"
            "Кнопка 2 - http://example2.com\n"
            "\n"
            "Використовуй роздільник \"|\", щоб додати до трьох кнопок в один ряд:\n"
            "\n"
            "Кнопка 1 - http://example1.com | Кнопка 2 - http://example2.com\n"
            "Кнопка 3 - http://example3.com | Кнопка 4 - http://example4.com\n"
        ), reply_markup=kb)


@dp.message_handler(state=FSMEditPost.reply_markup, content_types=ContentTypes.all(), is_private_chat=True)
async def editpost_reply_markup_func(message: types.Message, state: FSMContext):
    log(f"Get editpost reply_markup by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return
    
    if message.text == "Пост без кнопок":
        reply_markup = None
    else:
        try:
            rows = message.text.split("\n")
            kb_list = []
            for row in rows:
                buttons = row.split(" | ")
                if len(buttons) > 3:
                    await message.answer("Не можна більше 3 кнопок в ряд")
                    return
                buttons_row = []
                for button in buttons:
                    parts = button.split(" - ")
                    if len(parts) != 2:
                        raise ValueError()
                    buttons_row.append(InlineKeyboardButton(*parts))
                kb_list.append(buttons_row)
        except:
            await message.answer("Неправильний формат размітки, спробуй знову")
            return

        reply_markup = InlineKeyboardMarkup(inline_keyboard=kb_list)

    async with state.proxy() as data:
        msg = data["msg"]
        await bot.edit_message_reply_markup(msg.forward_from_chat.id, msg.forward_from_message_id, reply_markup=reply_markup)
        await message.answer("Кнопки поста успішно відредаговано", reply_markup=to_main_menu_kb)
    
    await state.finish()


class FSMStealPost(StatesGroup):
    get_post = State()
    channel_id = State()
    notify = State()
    delete_on = State()
    need_off_comments = State()
    reply_to = State()
    schedule = State()


@dp.message_handler(lambda m: m.text == "Скопіювати пост", is_private_chat=True)
async def steal_post_func(message: types.Message):
    log(f"Steal_post pressed by user {message.chat.id}", LogMode.INFO)

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Перегляд"),
        ],
        [
            KeyboardButton(text="Відмінити"),
        ],
    ], resize_keyboard=True)

    await message.answer("Перешли пост в цей чат і натисни Перегляд", reply_markup=kb)
    await FSMStealPost.get_post.set()


@dp.message_handler(state=FSMStealPost.get_post, content_types=ContentTypes.all(), is_private_chat=True)
async def stealpost_get_post_func(message: types.Message, state: FSMContext):
    log(f"Get stealpost get post by user {message.chat.id}", LogMode.INFO)

    if message.caption and len(message.caption) > 1024:
        await message.answer(f"Пост не був прийнятий, оскільки в ньому більше 1024 символів, а саме: {len(message.caption)}")
        return

    if message.text == "Перегляд":
        async with state.proxy() as data:
            post_type = data.get("post_type")
            post_source = data.get("post_source")
            if not post_type or not post_source:
                await message.answer("Спочатку надішли донорський пост")
                return
        await message.answer("Перегляд поста:")
    elif not message.media_group_id:
        async with state.proxy() as data:
            data["post_type"] = "solo"
            data["post_source"] = message
            return
    else:
        async with state.proxy() as data:
            data["post_type"] = "album"
            data["post_source"] = data.get("post_source", []) + [message]
            return
    
    if post_type == "solo":
        post_source: types.Message
        ms = await app.get_messages(post_source.chat.id, post_source.message_id)
        try:
            if not post_source.to_python().get('link_preview_options') or post_source.to_python().get('link_preview_options').get('is_disabled'):
                async with state.proxy() as data:
                    data["disable_preview"] = True
                await app.copy_message(ms.chat.id, ms.chat.id, ms.id, reply_markup=ms.reply_markup)
            else:
                async with state.proxy() as data:
                    data["disable_preview"] = False
                await app.send_message(ms.chat.id, ms.text, entities=ms.entities, disable_web_page_preview=False, reply_markup=ms.reply_markup)
        except pyro_exceptions.bad_request_400.MediaCaptionTooLong:
            await message.answer(f"Завеликий текст ({len(post_source.text or post_source.caption)}). Ліміт Telegram для ботів для медіа постів: 1024, для звичайних текстових: 4096. Зменшуй текст, кидай пост заново і натисни Перегляд")
            return
    else:
        media = MediaGroup()
        for x in post_source:
            x: types.Message
            if x.photo:
                media.attach_photo(x.photo[0].file_id, caption=(x.parse_entities() if x.caption else ""))
            elif x.video:
                media.attach_video(x.video.file_id, x.video.thumb.file_id, caption=(x.parse_entities() if x.caption else ""), width=x.video.width, height=x.video.height, duration=x.video.duration)
            else:
                continue

        await bot.send_media_group(message.chat.id, media)

    await FSMStealPost.next()

    res = await cur_executor("SELECT channel_id FROM channel_admins WHERE user_id=?;", message.chat.id)
    if not res:
        res = await cur_executor("SELECT channel_id FROM channel_editors WHERE user_id=?;", message.chat.id)
    
    channels_kb_list = []
    channels_kb_list.append([InlineKeyboardButton(text="Обрати всі", callback_data=f"channel_choose_all")])
    channels_kb_list.append([InlineKeyboardButton(text="Відмінити всі", callback_data=f"channel_cancel_all")])
    for row in res:
        channel_id = - (1_000_000_000_000 + int(row[0]))
        
        is_admin = False
        try:
            chat_member = await bot.get_chat_member(channel_id, message.chat.id)
        except tg_exceptions.BadRequest as e:
            if e.text != "User not found":
                raise e
        else:
            if chat_member.status in ["administrator", "owner", "creator"]:
                is_admin = True
        if not is_admin:
            continue

        channel = await bot.get_chat(channel_id)
        button = InlineKeyboardButton(text=channel.title, callback_data=f"channel_{channel_id}")
        channels_kb_list.append([button])

    if len(channels_kb_list) == 2:
        await message.answer("В жодному каналі у тебе немає прав адміністратора, процедуру перервано", reply_markup=to_main_menu_kb)
        await state.finish()
        return
    
    channels_kb_list.append([InlineKeyboardButton(text="Готово", callback_data=f"channel_accept")])

    await message.answer("Обери потрібні канали натиснувши на відповідні кнопки", reply_markup=InlineKeyboardMarkup(inline_keyboard=channels_kb_list))


@dp.callback_query_handler(Text(startswith="channel_"), state=FSMStealPost.channel_id)
async def stealpost_channel_id_func(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()

    channel_id = callback.data.split("_", 1)[1]

    if channel_id == "choose_all":
        for row in callback.message.reply_markup.inline_keyboard[2:-1]:
            if row[0].text[0] != "✅":
                row[0].text = "✅" + row[0].text
        
        try:
            await callback.message.edit_reply_markup(callback.message.reply_markup)
        except tg_exceptions.MessageNotModified:
            pass
    elif channel_id == "cancel_all":
        for row in callback.message.reply_markup.inline_keyboard[2:-1]:
            if row[0].text[0] == "✅":
                row[0].text = row[0].text[1:]
        
        try:
            await callback.message.edit_reply_markup(callback.message.reply_markup)
        except tg_exceptions.MessageNotModified:
            pass
    elif channel_id == "accept":
        send_ids = []
        for row in callback.message.reply_markup.inline_keyboard[1:-1]:
            if row[0].text[0] == "✅":
                send_ids.append(int(row[0].callback_data.split("_")[1]))
        
        await callback.message.edit_reply_markup()
        
        async with state.proxy() as data:
            data["send_ids"] = send_ids

        await FSMStealPost.next()

        await callback.message.answer((
                "Відправити пост зі сповіщенням?"
            ), reply_markup=ReplyKeyboardMarkup(
                keyboard=[
                    [
                        KeyboardButton("Так"),
                    ],
                    [
                        KeyboardButton("Ні"),
                    ],
                ], resize_keyboard=True, input_field_placeholder="Обери дію нижче"
            ))
    else:
        for row in callback.message.reply_markup.inline_keyboard[1:-1]:
            if row[0].callback_data == callback.data:
                if row[0].text[0] == "✅":
                    row[0].text = row[0].text[1:]
                else:
                    row[0].text = "✅" + row[0].text
        await callback.message.edit_reply_markup(callback.message.reply_markup)


@dp.message_handler(state=FSMStealPost.notify, content_types=ContentTypes.all(), is_private_chat=True)
async def stealpost_notify_func(message: types.Message, state: FSMContext):
    log(f"Get stealpost notify by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return
    if message.text not in ["Так", "Ні"]:
        await message.answer("Відправ мені Так чи Ні")
        return

    if message.text == "Так":
        async with state.proxy() as data:
            data["notify"] = True
        await FSMStealPost.next()
    elif message.text == "Ні":
        async with state.proxy() as data:
            data["notify"] = False
        await FSMStealPost.next()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="24", callback_data="stealpost_delete_on_24")
            ],
            [
                InlineKeyboardButton(text="48 (47.5)", callback_data="stealpost_delete_on_48")
            ],
            [
                InlineKeyboardButton(text="Без автовидалення", callback_data="stealpost_delete_on_never")
            ],
        ]
    )

    await message.answer(f"Обери, через скільки годин після публікації видалити пост", reply_markup=kb)


@dp.callback_query_handler(Text(startswith="stealpost_delete_on_"), state=FSMStealPost.delete_on)
async def stealpost_delete_on_func(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()

    delete_on = callback.data.split("stealpost_delete_on_", 1)[1]

    await callback.message.delete()

    async with state.proxy() as data:
        data["delete_on"] = delete_on
    await FSMStealPost.next()

    await callback.message.answer((
        "Вимкнути коментарі до поста? (по можливості)"
    ), reply_markup=ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton("Так"),
            ],
            [
                KeyboardButton("Ні"),
            ],
        ], resize_keyboard=True, input_field_placeholder="Обери дію нижче"
    ))


@dp.message_handler(state=FSMStealPost.need_off_comments, content_types=ContentTypes.all(), is_private_chat=True)
async def stealpost_need_off_comments_func(message: types.Message, state: FSMContext):
    log(f"Get stealpost need_off_comments by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return
    if message.text not in ["Так", "Ні"]:
        await message.answer("Відправ мені Так чи Ні")
        return

    if message.text == "Так":
        async with state.proxy() as data:
            data["need_off_comments"] = True
        await FSMStealPost.next()
    elif message.text == "Ні":
        async with state.proxy() as data:
            data["need_off_comments"] = False
        await FSMStealPost.next()

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Без реплая"),
        ],
        [
            KeyboardButton(text="Відмінити"),
        ],
    ], resize_keyboard=True)

    await message.answer(f"Вкажи параметри для реплая: без нього (кнопка знизу) чи з ним - відправ посилання на один з постів в каналі виду https://t.me/c/1527486405/15087", reply_markup=kb)


@dp.message_handler(state=FSMStealPost.reply_to, content_types=ContentTypes.all(), is_private_chat=True)
async def stealpost_reply_to_func(message: types.Message, state: FSMContext):
    log(f"Get stealpost reply_to by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return

    if message.text == "Без реплая":
        async with state.proxy() as data:
            data["reply_to_post_id"] = None
        await FSMStealPost.next()
    else:
        # https://t.me/c/1527486405/15087
        if not message.text.startswith("https://t.me/"):
            await message.answer("Некоректний формат посилання, спробуй знову. Приклад коректного: https://t.me/c/1527486405/15087")
            return

        if message.text.startswith("https://t.me/c/"):
            ids = message.text[15:]
            try:
                ids = ids.split("/")
                if len(ids) != 2:
                    raise ValueError()
                for i in ids:
                    if int(i) < 0:
                        raise ValueError()
            except:
                await message.answer("Некоректний формат посилання, спробуй знову. Приклад коректного: https://t.me/c/1527486405/15087")
                return
        else:
            ids = message.text[13:]
            try:
                ids = ids.split("/")
                if len(ids) != 2:
                    raise ValueError()
                username, post_id = ids
                if int(post_id) < 0:
                    raise ValueError()
                try:
                    ch = await bot.get_chat("@"+username)
                    ids[0] = ch.id
                    if ids[0] < 0:
                        ids[0] = - (1_000_000_000_000 + ids[0])
                except Exception as e:
                    log(f"Can not resolve username for reply: '{type(e)}', '{e}'")
                    await message.answer(f"Не вдалося розпізнати юзернейм, спробуй знову")
                    return
            except:
                await message.answer("Некоректний формат посилання, спробуй знову. Приклад коректного: https://t.me/c/1527486405/15087")
                return

        channel_id, post_msg_id = ids
        channel_id = - (1_000_000_000_000 + int(channel_id))
        post_msg_id = int(post_msg_id)
        data = await cur_executor("SELECT * FROM posted_ids;")
        for row in data:
            post_id, posted_ids_data = row
            posted_ids_data: dict = json.loads(posted_ids_data)
            if post_msg_id in posted_ids_data.get(str(channel_id), []):
                async with state.proxy() as data:
                    data["reply_to_post_id"] = post_id
                await FSMStealPost.next()
                break
        else:
            await message.answer("Не знайдено записів з такими айдішками канала і поста в каналі, спробуй знову. Приклад коректного: https://t.me/c/1527486405/15087")
            return

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Відправити зараз"),
        ],
        [
            KeyboardButton(text="Відмінити"),
        ],
    ], resize_keyboard=True)

    await message.answer(f"Тепер відправ час по utc для відкладеної відправки у форматі 2025-06-23 02:11:58 (час на сервері: {get_dt_now()})", reply_markup=kb)


@dp.message_handler(state=FSMStealPost.schedule, content_types=ContentTypes.all(), is_private_chat=True)
async def stealpost_schedule_func(message: types.Message, state: FSMContext):
    log(f"Get stealpost schedule by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return

    if message.text == "Відправити зараз":
        async with state.proxy() as data:
            delete_on = data["delete_on"]
            if delete_on == "24":
                delete_on = int(get_dt_now().timestamp() + 24 * 3600)
            elif delete_on == "48":
                delete_on = int(get_dt_now().timestamp() + 47 * 3600 + 1800)
            
            posted_ids_data = dict()
            if data["reply_to_post_id"]:
                posted_ids_data: dict = json.loads((await cur_executor("SELECT posted_ids_data FROM posted_ids WHERE post_id=?;", data["reply_to_post_id"]))[0][0])

            posted_ids = dict()
            for channel_id in data["send_ids"]:
                notify = data["notify"]
                
                post_source: types.Message = data["post_source"]
                if data["post_type"] == "solo":
                    ms: pyro_types.Message = await app.get_messages(post_source.chat.id, post_source.message_id)
                    if not data["disable_preview"]:
                        msg = await app.send_message(channel_id, ms.text, entities=ms.entities, disable_web_page_preview=False, disable_notification=(not notify), reply_to_message_id=posted_ids_data.get(str(channel_id), [None])[0], reply_markup=ms.reply_markup)
                    else:
                        msg = await app.copy_message(channel_id, ms.chat.id, ms.id, ms.caption, caption_entities=ms.caption_entities, disable_notification=(not notify), reply_to_message_id=posted_ids_data.get(str(channel_id), [None])[0], reply_markup=ms.reply_markup)

                    posted_ids[channel_id] = [msg.id]

                    if delete_on != "never":
                        await cur_executor("INSERT INTO scheduled_deletes VALUES (?, ?, ?)", msg.id, channel_id, delete_on)
                else:
                    media = MediaGroup()
                    for x in post_source:
                        x: types.Message
                        сaption = (x.parse_entities() if x.caption else "")
                        if post_source.index(x) != 0:
                            сaption = ""
                        if x.photo:
                            media.attach_photo(x.photo[0].file_id, caption=сaption)
                        elif x.video:
                            media.attach_video(x.video.file_id, x.video.thumb.file_id, caption=сaption, width=x.video.width, height=x.video.height, duration=x.video.duration)
                        else:
                            continue

                    while True:
                        try:
                            msgs = await bot.send_media_group(channel_id, media, disable_notification=(not notify), reply_to_message_id=posted_ids_data.get(str(channel_id), [None])[0])
                            break
                        except tg_exceptions.NetworkError:
                            continue

                    ids = []
                    for mess in msgs:
                        ids.append(mess.message_id)
                    if ids:
                        posted_ids[channel_id] = ids

                    if delete_on != "never":
                        for mess in msgs:
                            await cur_executor("INSERT INTO scheduled_deletes VALUES (?, ?, ?)", mess.message_id, channel_id, delete_on)

                await asyncio.sleep(1)

            if data["need_off_comments"]:
                OFF_COMMENTS_QUEUE.append([posted_ids, datetime.datetime.utcnow().timestamp()])

            while True:
                post_id = gen_rand_text()
                if not await cur_executor("SELECT post_id FROM scheduled_posts WHERE post_id=?;", post_id) and not await cur_executor("SELECT post_id FROM posted_ids WHERE post_id=?;", post_id):
                    break

            await cur_executor("INSERT INTO posted_ids VALUES(?, ?);", post_id, json.dumps(posted_ids, ensure_ascii=False))

        await message.answer("Пост успішно скопійовано в обрані канали", reply_markup=to_main_menu_kb)
        await state.finish()
    else:
        try:
            dt = datetime.datetime.fromisoformat(message.text)
        except:
            await message.answer("Неправильний формат")
            return

        if dt <= get_dt_now():
            await message.answer("Не вказуй минулий час")
            return
        
        if (datetime.datetime.fromisoformat(message.text) - get_dt_now()).days >= 365:
            await message.answer("Не вказуй час далі, ніж на рік в майбутнє")
            return
        
        def make_markup_text(markup: InlineKeyboardMarkup):
            m_text = ""

            for row in markup.inline_keyboard:
                m_text += " | ".join(f"{button.text.replace('-', '—')} - {button.url}" for button in row) + "\n"

            return m_text.strip()

        async with state.proxy() as data:
            post_data = {
                "send_ids": data["send_ids"],
            }

            if not data.get("media_group"):
                data["media_group"] = []
            
            if data["post_type"] == "solo":
                post_source: types.Message = data["post_source"]
                if post_source.photo:
                    post_type = "solo"
                    info = [post_source.photo[-1].file_id, "photo"]
                    post_data["media_info"] = info
                    post_data["text_caption"] = (post_source.parse_entities() if post_source.caption else "")
                elif post_source.video:
                    post_type = "solo"
                    info = [post_source.video.file_id, "video"]
                    post_data["media_info"] = info
                    post_data["text_caption"] = (post_source.parse_entities() if post_source.caption else "")
                else:
                    post_type = "text"
                    post_data["text_caption"] = post_source.parse_entities()

                post_data["disable_preview"] = data["disable_preview"]
                post_data["reply_markup_text"] = make_markup_text(post_source.reply_markup) if post_source.reply_markup else "Пост без кнопок"
            else:
                post_type = "album"
                post_source: "list[types.Message]" = data["post_source"]
                for x in post_source:
                    x: types.Message
                    if x.photo:
                        info = [x.photo[-1].file_id, "photo"]
                    elif x.video:
                        info = [x.video.file_id, "video"]
                    else:
                        continue
                    
                    data["media_group"].append(info)
                
                post_data["media_info"] = data["media_group"]
                post_data["text_caption"] = (post_source[0].parse_entities() if post_source[0].caption else "")

            post_data["notify"] = data["notify"]
            post_data["delete_on"] = data["delete_on"]
            post_data["need_off_comments"] = data["need_off_comments"]
            post_data["reply_to_post_id"] = data["reply_to_post_id"]
        
        while True:
            post_id = gen_rand_text()
            if not await cur_executor("SELECT post_id FROM scheduled_posts WHERE post_id=?;", post_id) and not await cur_executor("SELECT post_id FROM posted_ids WHERE post_id=?;", post_id):
                break

        post_data_end = {
            "send_ids": post_data["send_ids"],
        }

        for send_id in post_data["send_ids"]:
            await cur_executor("INSERT INTO scheduled_posts VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);",
                               post_id,
                               - (1_000_000_000_000 + int(send_id)),
                               post_type,
                               post_data["reply_to_post_id"],
                               int(datetime.datetime.fromisoformat(message.text).timestamp()),
                               post_data.get("disable_preview", True),
                               post_data.get("reply_markup_text", ""),
                               post_data["notify"],
                               post_data["delete_on"],
                               post_data["need_off_comments"],
                               post_data["text_caption"],
                               json.dumps(post_data["media_info"], ensure_ascii=False, indent=4),
                               "scheduled",
                               json.dumps(post_data_end, ensure_ascii=False, indent=4),
                            )

        await message.answer(f"Скопійований пост успішно додано до запланованих (айді: {post_id})", reply_markup=to_main_menu_kb)
        
    await state.finish()


@dp.message_handler(lambda m: m.text == "Відкладені", is_private_chat=True)
async def schedule_func(message: types.Message):
    log(f"Schedule pressed by user {message.chat.id}", LogMode.INFO)

    res1 = await cur_executor("SELECT post_id FROM scheduled_posts WHERE status=? AND channel_id IN (SELECT channel_id FROM channel_admins WHERE user_id=?) OR channel_id IN (SELECT channel_id FROM channel_editors WHERE user_id=?);", "scheduled", message.chat.id, message.chat.id)
    if not res1:
        await message.answer("Немає відкладених постів")
        return
    
    selected_posts = []
    for row1 in res1:
        if row1[0] in selected_posts:
            continue
        selected_posts.append(row1[0])

        res2 = await cur_executor("SELECT post_id, channel_id, post_type, reply_to_post_id, schedule_timestamp, disable_preview, reply_markup_text, notify, delete_on, need_off_comments, text_caption, media_info, other_info FROM scheduled_posts WHERE post_id=?;", row1[0])
        send_ids = []
        for row2 in res2:
            post_id, channel_id, post_type, reply_to_post_id, schedule_timestamp, disable_preview, reply_markup_text, notify, delete_on, need_off_comments, text_caption, media_info, post_data = row2
            send_ids.append(channel_id)
        
        post_data: dict = json.loads(post_data)
        if post_type == "text":
            text = text_caption

            reply_markup = make_markup_for_post(reply_markup_text)

            await bot.send_message(message.chat.id, text, disable_web_page_preview=disable_preview, disable_notification=(not notify), reply_markup=reply_markup)
        elif post_type == "solo":
            info = json.loads(media_info)
            caption = text_caption
            reply_markup = make_markup_for_post(reply_markup_text)

            if info[1] == "photo":
                await bot.send_photo(message.chat.id, info[0], caption=caption, disable_notification=(not notify), reply_markup=reply_markup)
            elif info[1] == "video":
                await bot.send_video(message.chat.id, info[0], caption=caption, disable_notification=(not notify), reply_markup=reply_markup)
        elif post_type == "album":
            media_group_ids = json.loads(media_info)
            caption = text_caption
            
            mgi = media_group_ids[:]
            media = MediaGroup()
            info = mgi.pop(0)
            if info[1] == "photo":
                media.attach_photo(info[0], caption=caption)
            elif info[1] == "video":
                media.attach_video(info[0], caption=caption)
            for info in mgi:
                if info[1] == "photo":
                    media.attach_photo(info[0])
                elif info[1] == "video":
                    media.attach_video(info[0])

            await bot.send_media_group(message.chat.id, media, disable_notification=(not notify))
        
        await asyncio.sleep(1)

        channels_info = ""
        for channel_id in send_ids:
            channel_id = - (1_000_000_000_000 + int(channel_id)) # -10012345
            try:
                channel_chat = await bot.get_chat(channel_id)
                info = "@" + channel_chat.username if channel_chat.username else channel_chat.title
            except:
                info = "empty"
            channels_info += f"{ - (channel_id + 1_000_000_000_000)} - {info}\n" # 12345

        kb = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="Видалити з відкладених", callback_data=f"remove_schedule_{post_id}"),
            ],
        ])

        reply_info = ""
        if reply_to_post_id:
            reply_data: dict = json.loads((await cur_executor("SELECT posted_ids_data FROM posted_ids WHERE post_id=?;", reply_to_post_id))[0][0])
            for channel_id, ids in reply_data.items():
                reply_info += f"https://t.me/c/{ - (int(channel_id) + 1_000_000_000_000)}/{ids[0]}\n"
        if reply_info:
            reply_info = "Реплаєм на такі пости:\n" + reply_info

        off_comm = "Так" if need_off_comments else "Ні"

        await bot.send_message(message.chat.id, f"Пост вище (айді: <code>{post_id}</code>) (коментарі вимкнені: {off_comm}) буде відправлений {datetime.datetime.fromtimestamp(schedule_timestamp)} по utc в такі канали:\n\n{channels_info}\n\n{reply_info}", reply_markup=kb)
    
        await asyncio.sleep(1)
    
    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Змінити час"),
        ],
        [
            KeyboardButton(text="Головне меню"),
        ],
    ], resize_keyboard=True)

    await bot.send_message(message.chat.id, f"Всього постів {len(res1)} (час на сервері: {get_dt_now()})", reply_markup=kb)


@dp.callback_query_handler(Text(startswith="remove_schedule_"))
async def remove_schedule_func(callback: types.CallbackQuery):
    await callback.answer()

    post_id = callback.data.split("remove_schedule_")[1]

    await cur_executor("DELETE FROM scheduled_posts WHERE post_id=?;", post_id)

    await callback.message.edit_reply_markup()


class FSMChangeSchedule(StatesGroup):
    post_id = State()
    new_dt = State()


@dp.message_handler(lambda m: m.text == "Змінити час", is_private_chat=True)
async def change_schedule_func(message: types.Message):
    log(f"Change chedule pressed by user {message.chat.id}", LogMode.INFO)

    res = await cur_executor("SELECT post_id FROM scheduled_posts WHERE channel_id IN (SELECT channel_id FROM channel_admins WHERE user_id=?) OR channel_id IN (SELECT channel_id FROM channel_editors WHERE user_id=?);", message.chat.id, message.chat.id)
    if not res:
        await message.answer("Немає відкладених постів")
        return
    
    await FSMChangeSchedule.post_id.set()
    
    await message.answer("Відправ айді поста", reply_markup=cancel_kb)


@dp.message_handler(state=FSMChangeSchedule.post_id, content_types=ContentTypes.all(), is_private_chat=True)
async def changeschedule_post_id_func(message: types.Message, state: FSMContext):
    log(f"Get changeschedule post_id by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return

    res = await cur_executor("SELECT post_id FROM scheduled_posts WHERE post_id=? AND channel_id IN (SELECT channel_id FROM channel_admins WHERE user_id=?) OR channel_id IN (SELECT channel_id FROM channel_editors WHERE user_id=?);", message.text, message.chat.id, message.chat.id)
    if not res:
        await message.answer("Немає відкладеного поста з таким айді, спробуй знову")
        return

    async with state.proxy() as data:
        data["post_id"] = message.text
    
    await FSMChangeSchedule.next()

    await message.answer(f"Тепер відправ час по utc для відкладеної відправки у форматі 2025-06-23 02:11:58 (час на сервері: {get_dt_now()})", reply_markup=cancel_kb)


@dp.message_handler(state=FSMChangeSchedule.new_dt, content_types=ContentTypes.all(), is_private_chat=True)
async def changeschedule_new_dt_func(message: types.Message, state: FSMContext):
    log(f"Get changeschedule new_dt by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return

    try:
        dt = datetime.datetime.fromisoformat(message.text)
    except:
        await message.answer("Неправильний формат")
        return

    if dt <= get_dt_now():
        await message.answer("Не вказуй минулий час")
        return
    
    if (datetime.datetime.fromisoformat(message.text) - get_dt_now()).days >= 365:
        await message.answer("Не вказуй час далі, ніж на рік в майбутнє")
        return
    
    async with state.proxy() as data:
        post_id = data["post_id"]
    
    await state.finish()

    await cur_executor("UPDATE scheduled_posts SET schedule_timestamp=? WHERE post_id=?;", int(datetime.datetime.fromisoformat(message.text).timestamp()), post_id)

    await message.answer("Час успішно змінено", reply_markup=to_main_menu_kb)


@dp.message_handler(lambda m: m.text == "Підписи", is_private_chat=True)
async def signatures_func(message: types.Message):
    log(f"Signatures pressed by user {message.chat.id}", LogMode.INFO)

    kb = ReplyKeyboardMarkup(keyboard=[
        [
            KeyboardButton(text="Додати підпис"),
        ],
        [
            KeyboardButton(text="Головне меню"),
        ],
    ], resize_keyboard=True)

    res = await cur_executor("SELECT * FROM signatures WHERE channel_id IN (SELECT channel_id FROM channel_admins WHERE user_id=?) OR channel_id IN (SELECT channel_id FROM channel_editors WHERE user_id=?);", message.chat.id, message.chat.id)
    if not res:
        await message.answer("В базі немає підписів", reply_markup=kb)
        return
    
    admin_in = 0
    for row in res:
        channel_id, signature = row
        channel_id = - (1_000_000_000_000 + int(row[0]))

        is_admin = False
        try:
            chat_member = await bot.get_chat_member(channel_id, message.chat.id)
        except tg_exceptions.BadRequest as e:
            if e.text != "User not found":
                raise e
        else:
            if chat_member.status in ["administrator", "owner", "creator"]:
                is_admin = True
        if not is_admin:
            continue

        admin_in += 1

        try:
            channel_chat = await bot.get_chat(channel_id)
            info = "@" + channel_chat.username if channel_chat.username else channel_chat.title
        except:
            info = "empty"
        
        channel_info = f"{- (channel_id + 1_000_000_000_000)} - {info}"

        text = channel_info + "\n\n" + signature

        signature_kb = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="Змінити підпис", callback_data=f"edit_signature_{channel_id}"),
            ],
            [
                InlineKeyboardButton(text="Видалити підпис", callback_data=f"remove_signature_{channel_id}"),
            ],
        ])

        await bot.send_message(message.chat.id, text, reply_markup=signature_kb)

        await asyncio.sleep(1)
    
    await bot.send_message(message.chat.id, f"Всього доступних підписів: {admin_in}. Видалення відбувається одразу", reply_markup=kb)


@dp.callback_query_handler(Text(startswith="remove_signature_"))
async def remove_signature_func(callback: types.CallbackQuery):
    await callback.answer()

    channel_id = callback.data.split("remove_signature_")[1]

    await cur_executor("DELETE FROM signatures WHERE channel_id=?", channel_id)

    await callback.message.edit_reply_markup()


class FSMAddEditSignature(StatesGroup):
    channel_id = State()
    signature = State()


@dp.callback_query_handler(Text(startswith="edit_signature_"))
async def edit_signature_func(callback: types.CallbackQuery):
    await callback.answer()

    channel_id = callback.data.split("edit_signature_")[1]

    await FSMAddEditSignature.channel_id.set()

    state = Dispatcher.get_current().current_state()

    async with state.proxy() as data:
        data["channel_id"] = channel_id
    await FSMAddEditSignature.next()
    
    await callback.message.answer("Тепер відправ підпис", reply_markup=cancel_kb)


@dp.message_handler(lambda m: m.text == "Додати підпис", is_private_chat=True)
async def add_edit_signature_func(message: types.Message):
    log(f"Add edit signature pressed by user {message.chat.id}", LogMode.INFO)

    res = await cur_executor("SELECT channel_id FROM channel_admins WHERE user_id=?;", message.chat.id)
    if not res:
        res = await cur_executor("SELECT channel_id FROM channel_editors WHERE user_id=?;", message.chat.id)
    
    if not res:
        await message.answer("Спочатку додай хоча б один канал", reply_markup=to_main_menu_kb)
        return

    channels_kb_list = []
    for row in res:
        channel_id = - (1_000_000_000_000 + int(row[0]))
        
        is_admin = False
        try:
            chat_member = await bot.get_chat_member(channel_id, message.chat.id)
        except tg_exceptions.BadRequest as e:
            if e.text != "User not found":
                raise e
        else:
            if chat_member.status in ["administrator", "owner", "creator"]:
                is_admin = True
        if not is_admin:
            continue

        channel = await bot.get_chat(channel_id)
        button = InlineKeyboardButton(text=channel.title, callback_data=f"channel_{channel_id}")
        channels_kb_list.append([button])

    if not channels_kb_list:
        await message.answer("В жодному каналі у тебе немає прав адміністратора, процедуру перервано", reply_markup=to_main_menu_kb)
        return
    
    await message.answer("Обери канал", reply_markup=InlineKeyboardMarkup(inline_keyboard=channels_kb_list))
    await FSMAddEditSignature.channel_id.set()


@dp.callback_query_handler(Text(startswith="channel_"), state=FSMAddEditSignature.channel_id)
async def addeditsignature_channel_id_func(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()

    channel_id = callback.data.split("_", 1)[1]

    async with state.proxy() as data:
        data["channel_id"] = channel_id
    await FSMAddEditSignature.next()

    await callback.message.delete()

    await callback.message.answer("Тепер відправ підпис", reply_markup=cancel_kb)


@dp.message_handler(state=FSMAddEditSignature.signature, content_types=ContentTypes.all(), is_private_chat=True)
async def addeditsignature_signature_func(message: types.Message, state: FSMContext):
    log(f"Get addeditsignature signature by user {message.chat.id}", LogMode.INFO)

    if not message.text:
        await message.answer("Відправ мені текстове повідомлення")
        return

    async with state.proxy() as data:
        data["signature"] = message.parse_entities()

        channel_id = - (1_000_000_000_000 + int(data["channel_id"]))

        db_data = await cur_executor("SELECT * FROM signatures WHERE channel_id=?;", channel_id)

        if db_data:
            await cur_executor("UPDATE signatures SET signature=? WHERE channel_id=?;", data["signature"], channel_id)
        else:
            await cur_executor("INSERT INTO signatures VALUES (?, ?)", channel_id, data["signature"])

        await message.answer(f"Новий підпис встановлено:\n\n{data['signature']}", reply_markup=to_main_menu_kb)

    await state.finish()


@dp.message_handler(content_types=['text'], is_private_chat=True)
async def text_handler(message: types.Message):
    log(f"Get unknown text '{message.text or message.caption}' from user {message.chat.id}", LogMode.TIME)

    await message.answer("Я не знаю такої команди, відправ мені /start")


@dp.message_handler(content_types=ContentTypes.all(), is_private_chat=True)
async def all_handler(message: types.Message):
    log(f"Get illegal type of message from user {message.chat.id}", LogMode.TIME)

    await message.answer("Я не приймаю такі повідомлення, відправ мені /start")


@dp.errors_handler()
async def errors_handler(update: types.Update, e: Exception):
    text = f"Catch error:\n\nUpdate: {update}\n\n{''.join(traceback.format_exception(*sys.exc_info())).strip()}"

    log(text, LogMode.ERROR)

    with open("tempfile.txt", "w") as f:
        f.write(text)

    return True


if __name__ == "__main__":
    executor.start_polling(dp, on_startup=startup, on_shutdown=shutdown)
