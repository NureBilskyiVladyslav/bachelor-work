BOT_TOKEN = "123:asd-asd"
BOT_DEV_ID = 123
LOG_TO_FILE = False
API_ID = 123
API_HASH = "asd"
