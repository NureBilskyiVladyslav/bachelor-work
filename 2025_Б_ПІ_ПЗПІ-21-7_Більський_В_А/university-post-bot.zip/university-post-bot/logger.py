import config
from enum import Enum
from pathlib import Path
from datetime import datetime


class RGBColor():
    color_names = {
            "red": [255, 0, 0],
            "green": [0, 255, 0],
            "blue": [0, 100, 255],
            "white": [255, 255, 255],
            "black": [0, 0, 0],
            "orange": [255, 153, 0],
            "yellow": [255, 255, 0],
            "cyan": [0, 255, 255],
            "lightblue": [0, 200, 255],
            "violet": [120, 70, 200],
        }

    def __init__(self, red: int = -1, green: int = -1, blue: int = -1, color_name: str = "") -> None:
        if color_name:
            assert isinstance(color_name, str), f"Type of color_name must be str but now is {type(color_name).__name__}"

            if not self.color_names.get(color_name):
                raise ValueError((
                    f"Invalid color name '{color_name}'."
                    f" Use {__name__}.{__class__.__name__}.get_color_names() and choose one of them or"
                    f" set new by metod {__name__}.{__class__.__name__}.set_color_name()"
                ))
            
            self.init(*self.color_names[color_name])
        else:
            self.init(red, green, blue)

    def init(self, red: int, green: int, blue: int) -> None:
        assert isinstance(red, int), f"Type of red must be int but now is {type(red).__name__}"
        assert isinstance(green, int), f"Type of green must be int but now is {type(green).__name__}"
        assert isinstance(blue, int), f"Type of blue must be str int now is {type(blue).__name__}"

        for x in [red, green, blue]:
            if x < 0 or x > 255:
                raise ValueError("Use integer from 0 to 255")

        self.red = red
        self.green = green
        self.blue = blue

    @staticmethod
    def get_color_names() -> tuple:
        return tuple(__class__.color_names.keys())

    @staticmethod
    def set_color_name(red: int, green: int, blue: int, color_name: str) -> None:
        if not color_name:
            raise ValueError("Param color_name must not be empty")
        
        assert isinstance(red, int), f"Type of red must be int but now is {type(red).__name__}"
        assert isinstance(green, int), f"Type of green must be int but now is {type(green).__name__}"
        assert isinstance(blue, int), f"Type of blue must be str int now is {type(blue).__name__}"
        assert isinstance(color_name, str), f"Type of color_name must be str but now is {type(color_name).__name__}"

        for x in [red, green, blue]:
            if x < 0 or x > 255:
                raise ValueError("Use integer from 0 to 255")
        __class__.color_names[color_name] = [red, green, blue]


def colorize(text: str, color: RGBColor, on_color: RGBColor = None) -> str:
    assert isinstance(text, str), f"Type of text must be str but now is {type(text).__name__}"
    assert isinstance(color, RGBColor), f"Type of color must be RGBColor but now is {type(color).__name__}"

    bg = ""
    if on_color:
        assert isinstance(on_color, RGBColor), f"Type of on_color must be RGBColor but now is {type(color).__name__}"
        bg = f"48;2;{on_color.red};{on_color.green};{on_color.blue};"

    return (f"\033[{bg}38;2;{color.red};{color.green};{color.blue}m{text}\033[0m")


class LogMode(Enum):
    OK = RGBColor(color_name="green")
    INFO = RGBColor(color_name="blue")
    TIME = RGBColor(color_name="yellow")
    ERROR = RGBColor(color_name="red")
    DEFAULT = RGBColor(color_name="white")
    WARNING = RGBColor(color_name="violet")


def log(text: str, mode: "LogMode | RGBColor") -> None:
    log_time = colorize(str(datetime.now()), RGBColor(color_name="yellow"))

    color = mode if isinstance(mode, RGBColor) else mode.value

    log_text = log_time + " " + colorize(text, color)

    if config.LOG_TO_FILE == True:
        if not Path("../university-post-bot_logs").exists():
            Path("../university-post-bot_logs").mkdir()

        with open(f"../university-post-bot_logs/log_{datetime.now().date()}.txt", "a") as f:
            f.write(log_text + "\n")
    else:
        print(log_text)
